<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Études scientifiques avec les plateformes Medicapteurs · Medicapteurs</title>
<meta name="description" content="Près de 400 travaux publiés et 130 mémoires réalisés avec les plateformes Medicapteurs : podologie, posturologie, biomécanique, diabétologie.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">
<meta property="og:title" content="Études scientifiques avec les plateformes Medicapteurs">
<meta property="og:description" content="Près de 400 travaux publiés et 130 mémoires réalisés avec les plateformes Medicapteurs : podologie, posturologie, biomécanique, diabétologie.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-studies">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/" aria-current="page">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">

<section class="wrap page-head">
  <span class="mc-eyebrow">Recherche</span>
  <h1 class="h1 statement page-head__statement">Près de 400 travaux publiés.</h1>
  <p class="lead">Depuis 40 ans, Medicapteurs est partenaire de la recherche partout dans le monde, en podométrie, posturologie, biomécanique et diabétologie. Voici le recensement établi par Medicapteurs en janvier 2023.</p>
</section>

<section class="wrap" style="padding-bottom:48px">
  <div class="cmp-wrap">
    <table class="cmp cmp--studies">
      <thead><tr><th scope="col">Plateforme</th><th scope="col">Travaux publiés</th><th scope="col">Période</th><th scope="col">Mémoires et travaux non publiés</th><th scope="col">Listes complètes</th></tr></thead>
      <tbody>
        <tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a></th>
          <td><span class="bar" style="--w:100%"></span>96</td><td>2000 – 2022</td><td>19</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/winposturo-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-winposturo_01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod</a></th>
          <td><span class="bar" style="--w:98%"></span>94</td><td>2003 – 2022</td><td>59</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/winpod-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-winpod_01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a></th>
          <td><span class="bar" style="--w:88%"></span>84</td><td>2005 – 2022</td><td>11</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/fusyo-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-fusyo_01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr><tr>
          <th scope="row"><span class="mc-product"><span class="mc-sensor"></span>PEL38 (ancienne plateforme)</span></th>
          <td><span class="bar" style="--w:45%"></span>43</td><td>1983 – 2021</td><td>10</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/pel38-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/pel38-non-published-work-01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate · S-Plate</a></th>
          <td><span class="bar" style="--w:40%"></span>38</td><td>2007 – 2022</td><td>12</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/tplate-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoire-t-plate.s-plate.distributeurs.01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a></th>
          <td><span class="bar" style="--w:30%"></span>29</td><td>2009 – 2022</td><td>9</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/wintrack-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-wintrack_01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a></th>
          <td><span class="bar" style="--w:9%"></span>9</td><td>2014 – 2022</td><td>9</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/winshoe-published-work-01-2023.pdf" target="_blank" rel="noopener">Publiés</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-winshoe_01-2023.pdf" target="_blank" rel="noopener">Mémoires</a></td>
        </tr>
        <tr class="total"><th scope="row">Total</th><td>≈ 393</td><td>1983 – 2022</td><td>≈ 129</td><td></td></tr>
      </tbody>
    </table>
  </div>
  <div class="genres"><div class="mc-measure"><b>127</b><em>Publications</em></div><div class="mc-measure"><b>93</b><em>Articles</em></div><div class="mc-measure"><b>79</b><em>Résumés de congrès</em></div><div class="mc-measure"><b>33</b><em>Posters</em></div><div class="mc-measure"><b>14</b><em>Présentations</em></div></div>
  <p class="note">Les travaux « publiés » regroupent des articles, résumés de congrès, posters et présentations. Les listes complètes, par plateforme, sont téléchargeables ci-dessous. Environ 183 travaux en anglais et 154 en français.</p>
</section>
<section class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">Sélection</span><h2 class="h2">Quelques travaux</h2></div><a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/"><span class="mc-sensor"></span>Études pied diabétique</a></div>
    <div class="refs"><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Effect of the distance run and the rest periods on the static plantar pressure during a 24-hour running race</b><span>Farfaro M., Dumon L., Masmontet C. · European Journal of Human Movement, 2019</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Effectiveness of custom foot insoles to decrease plantar pressure: a cross-over randomized trial study</b><span>Casado-Hernández I., Becerro-de-Bengoa-Vallejo R., Losa-Iglesias M. · Healthcare, 2022</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>A cross-sectional study on the correlations between floating toe, plantar arch posture, and body sway</b><span>Wakoa M., Fujimaki T., Koyama K., Furuya N. · Foot and Ankle Surgery, 2022</span></div><div class="ref"><span class="mc-eyebrow">Fusyo</span><b>The effects of unilateral medial arch support stimulation on plantar pressure and center of pressure adjustment in young gymnasts</b><span>Janin M., Dupui P. · Neuroscience Letters, 2009</span></div><div class="ref"><span class="mc-eyebrow">Fusyo</span><b>Effect of eccentric isokinetic strengthening in the rehabilitation of patients with knee osteoarthritis: Isogo, a randomized trial</b><span>Jégu A.-G., Pereira B., Andant N., Coudeyre E. · Trials, 2014</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Biomechanical evaluation of diabetic foot through hierarchical cluster analysis</b><span>Sawacha Z., Spolaor F., Guarneri G. et al. · Université de Padoue</span></div><div class="ref"><span class="mc-eyebrow">Win-Track</span><b>Analysis of gait characteristics using a dynamic foot scanner in type 2 diabetes mellitus without peripheral neuropathy</b><span>Chenamgere G. S. K., Maiya A. G. et al. · Journal of Exercise Science and Physiotherapy, 2015</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Standing hindfoot alignment and body sway in healthy adolescents</b><span>Turci M., Ranghino C., Colaccino V., Grassi G. P. · poster, 2007</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>La baropodométrie</b><span>Cornu J.-Y., Dussaucy A., Jeunet L. · Progrès en médecine et chirurgie du pied, 2004</span></div><div class="ref"><span class="mc-eyebrow">Fusyo · Win-Pod</span><b>Sensibilité et motricité podales : leur influence sur le contrôle des activités posturo-cinétiques de sujets sains et pathologiques</b><span>Janin M. · thèse, Université Paul Sabatier Toulouse III, 2009</span></div></div>
  </div>
</section>
<section class="wrap sec">
  <span class="mc-eyebrow" style="margin-bottom:16px">Ils travaillent avec Medicapteurs</span>
  <div class="tiles"><div class="tile"><b>Marc Janin</b><span>Podologue, PhD. Master class de baropodométrie chez Medicapteurs en février 2017, webinaires 2020-2021.</span></div><div class="tile"><b>Jean-Yves Cornu</b><span>Podologue, nombreuses publications avec le Win-Pod.</span></div><div class="tile"><b>Marc Bourgeois</b><span>Biomécanicien.</span></div></div>
</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Essayez-la avec vos patients.</h2>
      <p>Démonstration de 30 minutes en visio, ou à votre cabinet selon votre région.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>de démonstration, en visio ou à votre cabinet</span></li><li><b>Clé en main</b><span>livraison, installation et formation en ligne</span></li><li><b>Reprise</b><span>de votre ancienne plateforme Medicapteurs</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">ou appelez-nous</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
