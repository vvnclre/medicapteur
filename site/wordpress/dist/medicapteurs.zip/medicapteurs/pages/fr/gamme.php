<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>La gamme : plateformes, pistes de marche et posturologie · Medicapteurs</title>
<meta name="description" content="Les 13 produits Medicapteurs comparés : Minipod, T-Plate, Win-Pod Wifi, Fusyo, Win-Posturo, Win-Track, PowerTrack, W-Inshoe. Trouvez la plateforme adaptée à votre pratique.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">
<meta property="og:title" content="La gamme : plateformes, pistes de marche et posturologie">
<meta property="og:description" content="Les 13 produits Medicapteurs comparés : Minipod, T-Plate, Win-Pod Wifi, Fusyo, Win-Posturo, Win-Track, PowerTrack, W-Inshoe. Trouvez la plateforme adaptée à votre pratique.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-range">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn data-current>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap page-head">
  <span class="mc-eyebrow">Produits</span>
  <h1 class="h1">Trouvez la plateforme faite pour votre pratique.</h1>
  <p class="lead">Répondez à trois questions, ou parcourez la gamme par famille. Chaque plateforme est livrée avec son logiciel.</p>
  <form class="finder" data-finder onsubmit="return false">
    <div class="finder__q"><label for="f-metier">1. Votre métier</label>
      <select class="select" id="f-metier" name="metier">
        <option value="podo">Podologue</option><option value="medecin">Médecin, diabétologue</option><option value="kine">Kiné, rééducation</option><option value="chercheur">Chercheur</option><option value="sport">Sport</option><option value="pharma">Pharmacie, orthèses</option><option value="autre">Autre</option>
      </select></div>
    <div class="finder__q"><label for="f-usage">2. Ce que vous mesurez</label>
      <select class="select" id="f-usage" name="usage">
        <option value="statique">Statique</option><option value="pas" selected>Un pas</option><option value="marche">Plusieurs pas</option><option value="course">La course</option><option value="posture">Posture et équilibre</option><option value="chaussure">Dans la chaussure</option>
      </select></div>
    <div class="finder__q"><label for="f-lieu">3. Où vous l&#39;utilisez</label>
      <select class="select" id="f-lieu" name="lieu">
        <option value="cabinet">Au cabinet</option><option value="mobile">En déplacement</option><option value="labo">En laboratoire</option>
      </select></div>
    <div class="finder__out" aria-live="polite">
      <div class="finder__reco"><strong>Notre conseil :</strong> <span data-finder-names><span class="mc-product"><span class="mc-sensor"></span>T-Plate</span> · <span class="mc-product"><span class="mc-sensor"></span>Win-Pod Wifi</span></span></div>
      <div class="finder__btns">
        <a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/" data-finder-see><span class="mc-sensor"></span><span>Voir la fiche</span></a>
        <a class="mc-btn mc-btn--primary" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/" data-finder-req><span class="mc-sensor"></span>Préparer ma demande</a>
      </div>
      <p class="muted" style="flex-basis:100%;font-size:15px;line-height:22px" data-finder-why></p>
    </div>
  </form>
</section>

<section class="wrap" style="padding-bottom:40px">
  <div class="family" id="mobile">
    <div class="family__head"><span class="mc-eyebrow">Mobile</span><h2 class="h2">Mesurer partout</h2><p>Une plateforme légère pilotée par smartphone ou tablette.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="Minipod" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Minipod</span></span>
        <p>La plateforme qui tient dans un sac, pilotée par smartphone.</p>
        <span class="mc-data">800 · 1 kg · 100 images/s</span>
      </a>
    </div>
  </div>
  <div class="family" id="cabinet">
    <div class="family__head"><span class="mc-eyebrow">Cabinet</span><h2 class="h2">Plateformes de baropodométrie</h2><p>Statique, dynamique et posture, avec le logiciel complet sur PC.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="T-Plate" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>T-Plate</span></span>
        <p>L&#39;examen podologique de tous les jours.</p>
        <span class="mc-data">1 600 · 400 × 400 mm · 3 kg</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="T-Plate 40" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>T-Plate 40</span><span class="tag-new">Nouveau</span></span>
        <p>L&#39;édition des 40 ans de Medicapteurs.</p>
        <span class="mc-data">Fiche technique à venir</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="T-Plate 30th" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>T-Plate 30th</span></span>
        <p>50 % de surface en plus et le logiciel toutes options.</p>
        <span class="mc-data">4 096 · 500 × 500 mm · 3,6 kg</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="XT-Plate" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>XT-Plate</span><span class="tag-new">Nouveau</span></span>
        <p>Légère et économique, en USB, Wifi ou Bluetooth.</p>
        <span class="mc-data">Fiche technique à venir</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="Win-Pod Wifi" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Pod Wifi</span></span>
        <p>La plateforme de référence, des faibles pressions aux plus fortes.</p>
        <span class="mc-data">2 304 · 0,4 – 100 N · 300 images/s</span>
      </a>
    </div>
  </div>
  <div class="family" id="posture">
    <div class="family__head"><span class="mc-eyebrow">Posturologie</span><h2 class="h2">Posture et équilibre</h2><p>Stabilométrie normalisée APE et rééducation par biofeedback.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="Fusyo" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Fusyo</span></span>
        <p>Podométrie et stabilométrie sur une seule plateforme.</p>
        <span class="mc-data">2 304 · 5 – 40 Hz · 250 kg</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="Win-Posturo" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Posturo</span></span>
        <p>La plateforme de stabilométrie et de rééducation posturale.</p>
        <span class="mc-data">16 bits · 5 – 40 Hz · 900 points/kg</span>
      </a>
    </div>
  </div>
  <div class="family" id="labo">
    <div class="family__head"><span class="mc-eyebrow">Laboratoire et sport</span><h2 class="h2">La marche, la course, la chaussure</h2><p>Plusieurs pas d&#39;affilée, la course sur tapis, la pression en conditions réelles.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="Win-Track" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Track</span></span>
        <p>La piste de marche d&#39;un seul tenant : 2 à 4 pas.</p>
        <span class="mc-data">12 288 · 200 images/s · 2 – 4</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="Win-Track Mini" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Track Mini</span></span>
        <p>La piste de marche d&#39;un mètre, qui tient dans un cabinet.</p>
        <span class="mc-data">8 192 · 1 000 × 500 mm · 200 images/s</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="PowerTrack" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>PowerTrack</span></span>
        <p>Le premier tapis de course 2-en-1.</p>
        <span class="mc-data">0,8 – 20 km/h · 200 images/s · 4</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="W-Inshoe" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>W-Inshoe</span></span>
        <p>La pression mesurée dans la chaussure, en conditions réelles.</p>
        <span class="mc-data">2 × 9 · 100 Hz · 50 g</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="W-Inshoe Easy" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>W-Inshoe Easy</span></span>
        <p>Les semelles instrumentées, prêtes à glisser dans la chaussure.</p>
        <span class="mc-data">4 · 8 · 35 – 46</span>
      </a>
    </div>
  </div>
</section>

<section id="comparateur" class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">Comparateur</span><h2 class="h2">Les plateformes côte à côte</h2></div></div>
    <div class="cmp-wrap">
      <table class="cmp">
        <thead><tr><td></td><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a></th></tr></thead>
        <tbody>
          <tr><th scope="row">Surface active</th><td>200 × 400 mm</td><td>400 × 400 mm</td><td>500 × 500 mm</td><td>400 × 400 mm</td><td>400 × 400 mm</td><td>1 500 × 500 mm</td></tr>
          <tr><th scope="row">Capteurs</th><td>800</td><td>1 600</td><td>4 096</td><td>2 304</td><td>2 304 + 3 jauges</td><td>12 288</td></tr>
          <tr><th scope="row">Taille d&#39;un capteur</th><td>10 × 10 mm</td><td>10 × 10 mm</td><td>7,8 × 7,8 mm</td><td>8 × 8 mm</td><td>8 × 8 mm</td><td>7,8 × 7,8 mm</td></tr>
          <tr><th scope="row">Fréquence max.</th><td>100 Hz</td><td>150 Hz</td><td>200 Hz <span class="check">à confirmer</span></td><td>300 Hz <span class="check">à confirmer</span></td><td>200 Hz <span class="check">à confirmer</span></td><td>200 Hz</td></tr>
          <tr><th scope="row">Connexion</th><td>Bluetooth · USB-C</td><td>USB · Wifi · Bluetooth</td><td>USB · Wifi</td><td>USB · Wifi</td><td>USB · Wifi</td><td>USB</td></tr>
          <tr><th scope="row">Pilotage</th><td class="txt">Smartphone, tablette</td><td class="txt">PC, tablette</td><td class="txt">PC, tablette</td><td class="txt">PC, tablette</td><td class="txt">PC</td><td class="txt">PC</td></tr>
          <tr><th scope="row">Stabilométrie APE</th><td class="txt">—</td><td class="txt">—</td><td class="txt">—</td><td class="txt">—</td><td class="txt">Oui</td><td class="txt">—</td></tr>
          <tr><th scope="row">Rapport pied diabétique</th><td class="txt">Oui</td><td class="txt">Oui</td><td class="txt">Oui</td><td class="txt">Oui</td><td class="txt">Oui</td><td class="txt">Oui</td></tr>
          <tr><th scope="row">Prix public</th><td>1 790 € TTC</td><td>sur devis</td><td>sur devis</td><td>8 319 € TTC <span class="check">à confirmer</span></td><td>sur devis</td><td>12 388 € TTC <span class="check">à confirmer</span></td></tr>
        </tbody>
      </table>
    </div>
    <p class="note" style="margin-top:14px">Valeurs issues des fiches et brochures Medicapteurs. Les valeurs signalées « à confirmer » sont en cours de validation.</p>
  </div>
</section>


<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Vous hésitez entre deux modèles ?</h2>
      <p>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>de démonstration, en visio ou à votre cabinet</span></li><li><b>Clé en main</b><span>livraison, installation et formation en ligne</span></li><li><b>Reprise</b><span>de votre ancienne plateforme Medicapteurs</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">ou appelez-nous</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


<script type="application/json" id="mc-products">{"minipod": {"name": "Minipod", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg", "price": "1 790 € TTC"}, "t-plate": {"name": "T-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg", "price": null}, "t-plate-40": {"name": "T-Plate 40", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg", "price": null}, "t-plate-30th": {"name": "T-Plate 30th", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg", "price": null}, "xt-plate": {"name": "XT-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg", "price": null}, "win-pod-wifi": {"name": "Win-Pod Wifi", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg", "price": "8 319 € TTC"}, "fusyo": {"name": "Fusyo", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg", "price": null}, "win-posturo": {"name": "Win-Posturo", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg", "price": null}, "win-track": {"name": "Win-Track", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg", "price": "12 388 € TTC"}, "win-track-mini": {"name": "Win-Track Mini", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg", "price": "9 925 € TTC"}, "powertrack": {"name": "PowerTrack", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg", "price": null}, "w-inshoe": {"name": "W-Inshoe", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg", "price": "3 495 € TTC"}, "w-inshoe-easy": {"name": "W-Inshoe Easy", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg", "price": "5 600 € TTC"}}</script>

<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/reco.js"></script>
<script>
(function () {
  var form = document.querySelector("[data-finder]");
  var data = JSON.parse(document.getElementById("mc-products").textContent);
  var lang = document.documentElement.lang;
  var names = form.querySelector("[data-finder-names]"), see = form.querySelector("[data-finder-see]"), why = form.querySelector("[data-finder-why]"), req = form.querySelector("[data-finder-req]");
  var base = req.getAttribute("href");
  function update() {
    var s = { metier: form.metier.value, usages: [form.usage.value], lieu: form.lieu.value };
    var r = window.mcReco(s, lang);
    names.innerHTML = r.slugs.map(function (k) { return '<a class="mc-product" href="' + data[k].url + '"><span class="mc-sensor"></span>' + data[k].name + "</a>"; }).join(" · ");
    see.href = data[r.slugs[0]].url;
    see.lastElementChild.textContent = see.lastElementChild.textContent.replace(/ ·.*$/, "") + " · " + data[r.slugs[0]].name;
    why.textContent = r.why;
    req.href = base + "?metier=" + s.metier + "&usage=" + s.usages[0] + "&lieu=" + s.lieu;
  }
  form.addEventListener("change", update);
  update();
})();
</script>

</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
