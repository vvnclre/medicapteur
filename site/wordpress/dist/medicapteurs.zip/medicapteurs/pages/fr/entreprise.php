<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>L&#39;entreprise : née au LAAS-CNRS, fabriquée à Balma · Medicapteurs</title>
<meta name="description" content="Medicapteurs conçoit et fabrique depuis 1985 des plateformes de mesure des pressions plantaires, issues des travaux du LAAS-CNRS sur la « peau artificielle ».">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">
<meta property="og:title" content="L&#39;entreprise : née au LAAS-CNRS, fabriquée à Balma">
<meta property="og:description" content="Medicapteurs conçoit et fabrique depuis 1985 des plateformes de mesure des pressions plantaires, issues des travaux du LAAS-CNRS sur la « peau artificielle ».">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-company">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn data-current>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap page-head">
  <span class="mc-eyebrow">L&#39;entreprise</span>
  <div class="soul">
    <div class="stack" style="gap:22px">
      <h1 class="statement soul__title">Née d&#39;une peau artificielle.</h1>
      <p class="soul__text">Née de la recherche et de la haute technologie du LAAS-CNRS de Toulouse, Medicapteurs a été créée en 1985 pour exploiter les travaux sur le capteur tactile connu sous le nom de « peau artificielle ». Depuis, l&#39;entreprise conçoit et fabrique des équipements pour les professionnels du pied, de la semelle et de la chaussure.</p>
    </div>
    <div class="soul__img"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/histo1.jpg" alt="Pieds posés sur une plateforme Medicapteurs" width="600" height="402"></div>
  </div>
</section>
<section class="sec sec--alt">
  <div class="wrap">
    <div class="figures"><div class="mc-measure"><b>1985</b><em>création</em></div><div class="mc-measure"><b>20 000+</b><em>appareils en service</em></div><div class="mc-measure"><b>~400</b><em>travaux publiés</em></div><div class="mc-measure"><b>100 %</b><em>conçu et fabriqué en France</em></div></div>
    <p class="note" style="margin-top:16px">Le chiffre de 20 000 appareils vient des brochures 2023 et 2026 ; il est à confirmer par Medicapteurs (utilisateurs, clients ou appareils).</p>
  </div>
</section>
<section class="wrap sec">
  <div class="benefits benefits--2"><div class="benefit"><b>Une gamme complète et évolutive</b><p>Medicapteurs développe des produits pour le secteur médical comme pour la conception et la vente de semelles et de chaussures. Win-Pod, Win-Posturo, Fusyo, Win-Track et leurs logiciels sont améliorés en permanence pour répondre aux attentes des praticiens.</p></div><div class="benefit"><b>Qualité et fiabilité</b><p>Medicapteurs bénéficie de la certification DEKRA relative aux dispositifs médicaux ayant une fonction de mesurage, qui impose notamment des tests finaux avant mise sur le marché. Conception et fabrication 100 % françaises.</p><span class="check">Année de certification à confirmer (1988 ou 2006)</span></div><div class="benefit"><b>Une implantation mondiale</b><p>Distribuée en Europe, en Amérique et en Asie, Medicapteurs est implantée à Toulouse (Balma) et à Nice (Sophia Antipolis). Son service recherche et développement travaille avec de nombreuses écoles de podologie européennes et des universités médicales de plusieurs pays, et améliore en continu les logiciels, les matériaux et le service client.</p></div><div class="benefit"><b>Partenaire de la recherche</b><p>Près de 400 travaux scientifiques publiés avec les plateformes Medicapteurs. En 2016, Medicapteurs a mené le projet « Serious GaRS » du programme européen Easynov : des plateformes en réseau sur lesquelles des patients âgés guident un avatar par leur équilibre, pour une rééducation collective qui recrée du lien social.</p></div></div>
</section>
<section class="dark-sec mc-on-inverse sec">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">Repères</span><h2 class="h2">40 ans de capteurs</h2></div></div>
    <ol class="timeline"><li><b>1985</b><span>Création de Medicapteurs pour valoriser la « peau artificielle » du LAAS-CNRS</span></li><li><b>~2010</b><span>Plus de 4 000 systèmes installés</span></li><li><b>2016</b><span>Plus de 12 000 clients équipés · projet européen Serious GaRS</span></li><li><b>2017</b><span>Lancement de Physioplay, la rééducation ludique</span></li><li><b>2018</b><span>Podocapture, première application mobile à piloter une plateforme Wifi · plus de 15 000 systèmes</span></li><li><b>2019</b><span>Rapport pied diabétique automatique · nouvelle Fusyo 3</span></li><li><b>2023</b><span>Plus de 20 000 appareils en service dans le monde</span></li><li><b>2024</b><span>PowerTrack, le tapis de course 2-en-1 · Minipod</span></li><li><b>2026</b><span>T-Plate 40 pour les 40 ans · rapport synthétique automatique · XT-Plate</span></li></ol>
  </div>
</section>
<section class="wrap sec">
  <div class="split">
    <div class="stack">
      <span class="mc-eyebrow">Dans le monde</span>
      <h2 class="h2">Utilisateurs dans le monde</h2>
      <p class="body-text">Ils utilisent Medicapteurs : podologues, médecins, kinésithérapeutes, biomécaniciens, diabétologues, fabricants de chaussures et de semelles, magasins de sport, hôpitaux et laboratoires de recherche.</p>
      <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/" style="align-self:flex-start">Distribution</a>
    </div>
    <figure class="map"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/carte-clients.jpg" alt="Carte des pays équipés" width="991" height="388" loading="lazy"></figure>
  </div>
</section>
<section class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">Équipe</span><h2 class="h2">Qui vous répond</h2></div></div>
    <div class="tiles team-tiles"><div class="tile" style="background:var(--surface)"><b>Olivier</b><span>Directeur</span></div><div class="tile" style="background:var(--surface)"><b>Eric</b><span>Directeur technique</span></div><div class="tile" style="background:var(--surface)"><b>Laura</b><span>Développeuse</span></div><div class="tile" style="background:var(--surface)"><b>Laurent</b><span>Export</span></div><div class="tile" style="background:var(--surface)"><b>Tully</b><span>Commerciale</span></div></div>
    <p class="note" style="margin-top:14px">Équipe affichée sur l&#39;ancien site (2017), à mettre à jour.</p>
  </div>
</section>
<section class="wrap sec">
  <div class="tiles">
    <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/"><span class="mc-product"><span class="mc-sensor"></span>Ingénierie sur mesure</span><p>Notre savoir-faire est à votre disposition pour réaliser vos projets sur mesure dans l&#39;analyse des pressions réparties...</p></a>
    <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/"><span class="mc-product"><span class="mc-sensor"></span>Actualités</span><p>Medicapteurs à MEDICA 2026, hall 4, stand H22-1</p></a>
    <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/"><span class="mc-product"><span class="mc-sensor"></span>Études</span><p>Près de 400 travaux publiés.</p></a>
  </div>
</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Essayez-la avec vos patients.</h2>
      <p>Démonstration de 30 minutes en visio, ou à votre cabinet selon votre région.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>de démonstration, en visio ou à votre cabinet</span></li><li><b>Clé en main</b><span>livraison, installation et formation en ligne</span></li><li><b>Reprise</b><span>de votre ancienne plateforme Medicapteurs</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">ou appelez-nous</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
