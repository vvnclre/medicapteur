<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Préparer ma demande de devis ou de démonstration · Medicapteurs</title>
<meta name="description" content="Quatre questions sur votre pratique : Medicapteurs vous indique la plateforme adaptée et votre demande arrive complète chez le bon interlocuteur.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">
<meta property="og:title" content="Préparer ma demande de devis ou de démonstration">
<meta property="og:description" content="Quatre questions sur votre pratique : Medicapteurs vous indique la plateforme adaptée et votre demande arrive complète chez le bon interlocuteur.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-request">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap page-head" style="padding-bottom:8px">
  <span class="mc-eyebrow">2 minutes · sans engagement</span>
  <h1 class="h1">Préparer ma demande</h1>
  <p class="lead">Répondez à quatre questions : nous vous indiquons la plateforme adaptée et votre demande arrive complète chez le bon interlocuteur.</p>
</section>

<section class="wrap" style="padding-bottom:64px">
  <form class="req" data-req novalidate data-to="commercial@medicapteurs.fr">
    <div>
      <fieldset class="req__q">
        <legend><span class="req__n">1/4</span>Quel est votre métier ?</legend>
        <div class="opts"><label class="opt"><input type="radio" name="metier" value="podo" data-label="Podologue" checked><span>Podologue</span></label><label class="opt"><input type="radio" name="metier" value="medecin" data-label="Médecin, diabétologue"><span>Médecin, diabétologue</span></label><label class="opt"><input type="radio" name="metier" value="kine" data-label="Kiné, rééducation"><span>Kiné, rééducation</span></label><label class="opt"><input type="radio" name="metier" value="chercheur" data-label="Chercheur"><span>Chercheur</span></label><label class="opt"><input type="radio" name="metier" value="sport" data-label="Sport"><span>Sport</span></label><label class="opt"><input type="radio" name="metier" value="pharma" data-label="Pharmacie, orthèses"><span>Pharmacie, orthèses</span></label><label class="opt"><input type="radio" name="metier" value="autre" data-label="Autre"><span>Autre</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend><span class="req__n">2/4</span>Que voulez-vous mesurer ?<small>Plusieurs réponses possibles.</small></legend>
        <div class="opts"><label class="opt"><input type="checkbox" name="usage" value="statique" data-label="Statique" checked><span>Statique</span></label><label class="opt"><input type="checkbox" name="usage" value="pas" data-label="Un pas" checked><span>Un pas</span></label><label class="opt"><input type="checkbox" name="usage" value="marche" data-label="Plusieurs pas"><span>Plusieurs pas</span></label><label class="opt"><input type="checkbox" name="usage" value="course" data-label="La course"><span>La course</span></label><label class="opt"><input type="checkbox" name="usage" value="posture" data-label="Posture et équilibre"><span>Posture et équilibre</span></label><label class="opt"><input type="checkbox" name="usage" value="chaussure" data-label="Dans la chaussure"><span>Dans la chaussure</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend><span class="req__n">3/4</span>Où l&#39;utiliserez-vous ?</legend>
        <div class="opts"><label class="opt"><input type="radio" name="lieu" value="cabinet" data-label="Au cabinet" checked><span>Au cabinet</span></label><label class="opt"><input type="radio" name="lieu" value="mobile" data-label="En déplacement"><span>En déplacement</span></label><label class="opt"><input type="radio" name="lieu" value="labo" data-label="En laboratoire"><span>En laboratoire</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend><span class="req__n">4/4</span>Que souhaitez-vous recevoir ?<small>Plusieurs réponses possibles.</small></legend>
        <div class="opts"><label class="opt"><input type="checkbox" name="suite" value="demo" data-label="Une démonstration" checked><span>Une démonstration</span></label><label class="opt"><input type="checkbox" name="suite" value="devis" data-label="Un devis" checked><span>Un devis</span></label><label class="opt"><input type="checkbox" name="suite" value="reprise" data-label="Une reprise de mon ancienne plateforme"><span>Une reprise de mon ancienne plateforme</span></label><label class="opt"><input type="checkbox" name="suite" value="doc" data-label="Une documentation"><span>Une documentation</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend>Vos coordonnées</legend>
        <div class="fields">
          <div class="fld"><label for="r-name">Nom et prénom</label><input id="r-name" name="name" autocomplete="name" required aria-describedby="r-name-err"><span class="err" id="r-name-err" hidden>Indiquez votre nom pour que nous sachions qui rappeler.</span></div>
          <div class="fld"><label for="r-city">Ville et pays</label><input id="r-city" name="city" autocomplete="address-level2"></div>
          <div class="fld"><label for="r-email">E-mail</label><input id="r-email" name="email" type="email" autocomplete="email" required aria-describedby="r-email-err"><span class="err" id="r-email-err" hidden>Indiquez une adresse e-mail complète, par exemple nom@cabinet.fr.</span></div>
          <div class="fld"><label for="r-tel">Téléphone <small>(facultatif)</small></label><input id="r-tel" name="tel" type="tel" autocomplete="tel"></div>
          <div class="fld fld--full"><label for="r-msg">Précisions <small>(facultatif)</small></label><textarea id="r-msg" name="msg" rows="3" placeholder="Par exemple : je souhaite voir le rapport pied diabétique sur un patient."></textarea></div>
        </div>
      </fieldset>
    </div>

    <aside class="req__side" aria-live="polite">
      <div class="reco">
        <span class="mc-eyebrow">Notre recommandation</span>
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" data-reco-img width="400" height="250">
        <span data-reco-names><span class="mc-product"><span class="mc-sensor"></span>T-Plate</span></span>
        <p data-reco-why></p>
        <span class="reco__price">Budget indicatif : <span data-reco-price>Prix sur devis</span></span>
      </div>
      <div class="recap">
        <span class="mc-eyebrow" style="margin-bottom:12px">Votre demande</span>
        <dl>
          <dt>Métier</dt><dd data-r="metier"></dd>
          <dt>Mesures</dt><dd data-r="usage"></dd>
          <dt>Lieu</dt><dd data-r="lieu"></dd>
          <dt>À recevoir</dt><dd data-r="suite"></dd>
          <dt>Transmise à</dt><dd data-r="to">Service commercial, Balma</dd>
        </dl>
      </div>
      <div class="req__send">
        <button class="mc-btn mc-btn--primary mc-btn--lg" type="submit"><span class="mc-sensor"></span>Envoyer ma demande<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></button>
        <span class="note">Votre logiciel de messagerie s&#39;ouvre avec la demande déjà rédigée : il ne reste qu&#39;à l&#39;envoyer. Vos données servent uniquement à vous répondre.</span>
        <div class="req__done" data-done hidden>Votre messagerie s&#39;est ouverte. Si rien ne s&#39;est passé, écrivez-nous à <a href="mailto:commercial@medicapteurs.fr">commercial@medicapteurs.fr</a>.</div>
        <span class="note">Vous préférez parler à quelqu&#39;un ? Appelez le <a href="tel:+33562571571" style="font-family:var(--font-mono)">+33 5 62 571 571</a>.</span>
      </div>
    </aside>
  </form>
</section>

<script type="application/json" id="mc-products">{"minipod": {"name": "Minipod", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg", "price": "1 790 € TTC"}, "t-plate": {"name": "T-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg", "price": null}, "t-plate-40": {"name": "T-Plate 40", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg", "price": null}, "t-plate-30th": {"name": "T-Plate 30th", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg", "price": null}, "xt-plate": {"name": "XT-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg", "price": null}, "win-pod-wifi": {"name": "Win-Pod Wifi", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg", "price": "8 319 € TTC"}, "fusyo": {"name": "Fusyo", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg", "price": null}, "win-posturo": {"name": "Win-Posturo", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg", "price": null}, "win-track": {"name": "Win-Track", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg", "price": "12 388 € TTC"}, "win-track-mini": {"name": "Win-Track Mini", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg", "price": "9 925 € TTC"}, "powertrack": {"name": "PowerTrack", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg", "price": null}, "w-inshoe": {"name": "W-Inshoe", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg", "price": "3 495 € TTC"}, "w-inshoe-easy": {"name": "W-Inshoe Easy", "url": "<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg", "price": "5 600 € TTC"}}</script>

<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/reco.js"></script>
<script>
(function () {
  var f = document.querySelector("[data-req]");
  var data = JSON.parse(document.getElementById("mc-products").textContent);
  var lang = document.documentElement.lang;
  var T = {
    toDefine: "à préciser", onRequest: "Prix sur devis",
    subject: "Demande depuis le site", reco: "Notre recommandation",
    labels: { metier: "Métier", usage: "Mesures", lieu: "Lieu", suite: "À recevoir", name: "Nom et prénom", city: "Ville et pays", email: "E-mail", tel: "Téléphone", msg: "Précisions" },
    toPosturo: "Agence posturologie, Sophia Antipolis", toDefault: "Service commercial, Balma"
  };
  /* Réponses reprises de la page précédente (comparateur, fiche produit) */
  var q = new URLSearchParams(location.search);
  if (q.get("metier")) f.querySelectorAll('[name=metier]').forEach(function (i) { i.checked = i.value === q.get("metier"); });
  if (q.get("lieu")) f.querySelectorAll('[name=lieu]').forEach(function (i) { i.checked = i.value === q.get("lieu"); });
  if (q.get("usage")) f.querySelectorAll('[name=usage]').forEach(function (i) { i.checked = i.value === q.get("usage"); });
  var wanted = q.get("produit") && data[q.get("produit")] ? q.get("produit") : null;

  function picked(name) { return Array.prototype.filter.call(f.querySelectorAll('[name=' + name + ']'), function (i) { return i.checked; }); }
  function labels(name) { var l = picked(name).map(function (i) { return i.getAttribute("data-label"); }); return l.length ? l.join(", ") : T.toDefine; }
  var current;
  function update() {
    var s = { metier: (picked("metier")[0] || {}).value, usages: picked("usage").map(function (i) { return i.value; }), lieu: (picked("lieu")[0] || {}).value };
    var r = window.mcReco(s, lang);
    var slugs = wanted ? [wanted] : r.slugs;
    current = slugs;
    f.querySelector("[data-reco-names]").innerHTML = slugs.map(function (k) { return '<a class="mc-product" href="' + data[k].url + '"><span class="mc-sensor"></span>' + data[k].name + "</a>"; }).join(" · ");
    f.querySelector("[data-reco-img]").src = data[slugs[0]].img;
    f.querySelector("[data-reco-why]").textContent = wanted ? "" : r.why;
    f.querySelector("[data-reco-price]").textContent = (!wanted && r.budget) || data[slugs[0]].price || T.onRequest;
    ["metier", "usage", "lieu", "suite"].forEach(function (n) { f.querySelector('[data-r=' + n + ']').textContent = labels(n); });
    f.querySelector("[data-r=to]").textContent = (s.metier === "kine" && s.usages.indexOf("posture") !== -1) ? T.toPosturo : T.toDefault;
  }
  f.addEventListener("change", function (e) { if (e.target.name !== "msg") { if (e.target.name === "usage" || e.target.name === "lieu" || e.target.name === "metier") wanted = null; update(); } });
  update();

  function check(input, ok) {
    var err = document.getElementById(input.id + "-err");
    input.setAttribute("aria-invalid", ok ? "false" : "true");
    if (err) err.hidden = ok;
    return ok;
  }
  var nameI = f.elements.name, mailI = f.elements.email;
  var validName = function () { return check(nameI, nameI.value.trim().length > 1); };
  var validMail = function () { return check(mailI, /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mailI.value.trim())); };
  nameI.addEventListener("blur", function () { if (nameI.value) validName(); });
  mailI.addEventListener("blur", function () { if (mailI.value) validMail(); });
  nameI.addEventListener("input", function () { if (nameI.getAttribute("aria-invalid") === "true") validName(); });
  mailI.addEventListener("input", function () { if (mailI.getAttribute("aria-invalid") === "true") validMail(); });

  f.addEventListener("submit", function (e) {
    e.preventDefault();
    var okName = validName(), okMail = validMail();
    if (!okName) { nameI.focus(); return; }
    if (!okMail) { mailI.focus(); return; }
    var L = T.labels, el = f.elements;
    var body = [
      L.name + " : " + el.name.value.trim(),
      L.city + " : " + (el.city.value.trim() || T.toDefine),
      L.email + " : " + el.email.value.trim(),
      L.tel + " : " + (el.tel.value.trim() || T.toDefine),
      "",
      L.metier + " : " + labels("metier"),
      L.usage + " : " + labels("usage"),
      L.lieu + " : " + labels("lieu"),
      L.suite + " : " + labels("suite"),
      T.reco + " : " + current.map(function (k) { return data[k].name; }).join(", "),
      "",
      el.msg.value.trim()
    ].join("\n");
    var subject = T.subject + " · " + labels("suite") + " · " + current.map(function (k) { return data[k].name; }).join(", ");
    location.href = "mailto:" + f.getAttribute("data-to") + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
    f.querySelector("[data-done]").hidden = false;
  });
})();
</script>

</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
