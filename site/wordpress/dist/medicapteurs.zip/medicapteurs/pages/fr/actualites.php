<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Actualités : salons, nouveautés, offres · Medicapteurs</title>
<meta name="description" content="Les actualités Medicapteurs : salons MEDICA, AFDP, FNP, Entretiens de podologie, lancements de produits.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/news/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">
<meta property="og:title" content="Actualités : salons, nouveautés, offres">
<meta property="og:description" content="Les actualités Medicapteurs : salons MEDICA, AFDP, FNP, Entretiens de podologie, lancements de produits.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-news">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn data-current>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">

<section class="wrap page-head">
  <span class="mc-eyebrow">Actualités</span>
  <h1 class="h1 statement page-head__statement">Actualités.</h1>
  <p class="lead">Salons, nouveautés et rendez-vous Medicapteurs.</p>
</section>

<section class="wrap" style="padding-bottom:56px">
  <ol class="news">
    <li class="news__it">
      <time datetime="2026-11-13">13 novembre 2026</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">Medicapteurs à MEDICA 2026, hall 4, stand H22-1</h2><p>Retrouvez-nous au plus grand salon mondial des équipements médicaux, à Düsseldorf.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2026-09-11">11 septembre 2026</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">Entretiens de Podologie à Poitiers, les 2 et 3 octobre 2026</h2><p>Medicapteurs expose aux Entretiens de Podologie de la FNP.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2026-03-10">10 mars 2026</time>
      <div class="news__body"><span class="mc-eyebrow">Nouveauté</span><h2 class="h3">Salon AFDP 2026 : la T-Plate 40</h2><p>Au Parc floral de Paris, Medicapteurs présente sa dernière née, la T-Plate « 40e anniversaire », avec le logiciel toutes options et son rapport synthétique généré automatiquement.</p><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/">T-Plate 40</a></div>
      
    </li>
    <li class="news__it">
      <time datetime="2025-02-26">26 février 2025</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">Salon de Podologie, 7 et 8 mars 2025 à Paris</h2><p>Venez poser vos questions et voir nos démonstrations. Intervention « Minipod : des podomètres pour tous ! ».</p><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/">Minipod</a></div>
      
    </li>
    <li class="news__it">
      <time datetime="2024-11-19">19 novembre 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">FNP 2024 à Paris, 22 et 23 novembre</h2><p>Rencontrez-nous sur notre stand au salon de la Fédération nationale des podologues. Entrée libre.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2024-11-14">14 novembre 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">MEDICA 2024, hall 4, stand H06-2</h2><p>Chaque année, Medicapteurs participe au plus grand salon mondial des équipements médicaux, du 11 au 14 novembre 2024.</p></div>
      <img class="news__img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/medica-stand.jpg" alt="" loading="lazy">
    </li>
    <li class="news__it">
      <time datetime="2024-02-23">23 février 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">Salon de la Podologie, 8 et 9 mars 2024 à Paris</h2><p>Au Parc floral de Paris, stand 4, pour découvrir Minipod et toute la gamme.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2024-01-08">8 janvier 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Nouveauté</span><h2 class="h3">PowerTrack, le tapis de course intelligent</h2><p>Un tapis de course équipé de capteurs de pression amovibles pour étudier les sportifs, la marche et la course ; une piste de marche pour l&#39;enfant et la personne âgée, posée au sol en 5 secondes.</p><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/">PowerTrack</a></div>
      
    </li>
    <li class="news__it">
      <time datetime="2023-09-28">28 septembre 2023</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">MEDICA 2023, stand 4H06</h2><p>Medicapteurs expose à MEDICA 2023.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2022-11-25">25 novembre 2022</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">ISPO 2022 à Munich</h2><p>Stand A3/426 : nos dernières technologies pour les magasins de sport.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2022-04-14">14 avril 2022</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">OT World, hall 1, stand 36</h2><p>Medicapteurs au salon international de l&#39;orthopédie technique de Leipzig.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2021-02-22">22 février 2021</time>
      <div class="news__body"><span class="mc-eyebrow">Événement</span><h2 class="h3">Journée portes ouvertes du 18 mars 2021</h2><p>Une journée de démonstrations en ligne, gratuite sur inscription.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2020-11-16">16 novembre 2020</time>
      <div class="news__body"><span class="mc-eyebrow">Événement</span><h2 class="h3">Stand virtuel le 19 novembre 2020</h2><p>Démonstrations en ligne de toute la gamme.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2020-04-06">6 avril 2020</time>
      <div class="news__body"><span class="mc-eyebrow">Formation</span><h2 class="h3">Webinaires Medicapteurs</h2><p>Un planning de webinaires par plateforme, avec Marc Janin, podologue PhD.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2019-10-17">17 octobre 2019</time>
      <div class="news__body"><span class="mc-eyebrow">Logiciel</span><h2 class="h3">Le rapport pied diabétique automatique</h2><p>Calcul du niveau de risque d&#39;ulcération (rapport avant-pied / arrière-pied, publication de David Armstrong), localisation des zones à risque, type de pied. Sur Win-Pod, Win-Track, Win-Track Mini et Fusyo.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2019-09-02">2 septembre 2019</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">44es Entretiens de Podologie à Paris, 4 et 5 octobre 2019</h2><p>Retrouvez Medicapteurs début octobre à Paris.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-11-26">26 novembre 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Salon</span><h2 class="h3">Rehacare and Orthopedic China 2019 à Canton</h2><p>Medicapteurs expose en Chine.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-08-29">29 août 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Événement</span><h2 class="h3">Journée de l&#39;innovation numérique, Montpellier</h2><p>Le 19 septembre 2018.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-03-15">15 mars 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Nouveauté</span><h2 class="h3">Podocapture, la première application mobile qui pilote une plateforme Wifi</h2><p>Gratuite sur l&#39;App Store et Google Play, pour Win-Pod Wifi et T-Plate Wifi.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-01-11">11 janvier 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Congrès</span><h2 class="h3">Congrès SOFAMEA à Toulouse · Journées internationales de posturologie à Madrid</h2><p>Medicapteurs au XVIIe congrès de la Société francophone d&#39;analyse du mouvement chez l&#39;enfant et l&#39;adulte, puis à Madrid du 26 au 28 janvier 2018.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2017-02-14">14 février 2017</time>
      <div class="news__body"><span class="mc-eyebrow">Formation</span><h2 class="h3">Master class de baropodométrie avec Marc Janin, PhD</h2><p>Du 23 au 25 février 2017, trois jours de master class chez Medicapteurs.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2017-01-01">1 janvier 2017</time>
      <div class="news__body"><span class="mc-eyebrow">Nouveauté</span><h2 class="h3">Medicapteurs lance Physioplay</h2><p>La rééducation visuo-posturale ludique et à la portée de tous.</p></div>
      
    </li>
  </ol>
</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Essayez-la avec vos patients.</h2>
      <p>Démonstration de 30 minutes en visio, ou à votre cabinet selon votre région.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>de démonstration, en visio ou à votre cabinet</span></li><li><b>Clé en main</b><span>livraison, installation et formation en ligne</span></li><li><b>Reprise</b><span>de votre ancienne plateforme Medicapteurs</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">ou appelez-nous</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
