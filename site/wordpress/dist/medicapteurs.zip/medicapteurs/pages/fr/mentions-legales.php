<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mentions légales et données personnelles · Medicapteurs</title>
<meta name="description" content="Mentions légales, conditions d&#39;utilisation et données personnelles du site Medicapteurs.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">
<meta property="og:title" content="Mentions légales et données personnelles">
<meta property="og:description" content="Mentions légales, conditions d&#39;utilisation et données personnelles du site Medicapteurs.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-legal">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">

<section class="wrap page-head">
  <span class="mc-eyebrow">Informations</span>
  <h1 class="h1 statement page-head__statement">Mentions légales.</h1>
  
</section>

<section class="wrap" style="padding-bottom:64px">
  <div class="prose"><h2>Éditeur</h2><p>Medicapteurs France SAS, 31130 Balma, France. Téléphone : +33 5 62 571 571. Numéro RCS, capital et directeur de la publication : à compléter par Medicapteurs.</p><h2>Hébergeur</h2><p>Ikoula, 175 rue d&#39;Aguesseau, 92100 Boulogne-Billancourt, France (RCS Nanterre B 417 680 618), d&#39;après l&#39;ancien site : à confirmer pour le nouveau site.</p><h2>Conditions d&#39;utilisation</h2><p>L&#39;accès au site confère un droit d&#39;usage privé, non collectif et non exclusif sur son contenu. Les textes, photographies, vidéos et infographies sont des œuvres protégées par le Code de la propriété intellectuelle : leur reproduction à des fins commerciales nécessite l&#39;accord exprès de Medicapteurs.</p><h2 id="donnees">Données personnelles</h2><p>Les informations envoyées par les formulaires du site servent uniquement à répondre à votre demande et ne sont transmises qu&#39;à Medicapteurs. Conformément au RGPD, vous disposez d&#39;un droit d&#39;accès, de rectification, d&#39;opposition et d&#39;effacement de vos données. Politique complète à fournir par Medicapteurs.</p><h2>Cookies</h2><p>Le site n&#39;utilise pas de cookie de suivi. Il mémorise seulement, dans votre navigateur, la langue choisie.</p></div>
</section>

</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
