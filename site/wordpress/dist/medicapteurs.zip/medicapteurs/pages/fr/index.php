<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Medicapteurs · Plateformes de baropodométrie et d&#39;analyse de la marche</title>
<meta name="description" content="Plateformes de baropodométrie, pistes de marche et plateformes de posturologie conçues et fabriquées à Balma depuis 1985. Rapport pied diabétique, 390 travaux scientifiques.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/">
<meta property="og:title" content="Medicapteurs · Plateformes de baropodométrie et d&#39;analyse de la marche">
<meta property="og:description" content="Plateformes de baropodométrie, pistes de marche et plateformes de posturologie conçues et fabriquées à Balma depuis 1985. Rapport pied diabétique, 390 travaux scientifiques.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-home">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr hdr--dark mc-on-inverse" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="hero mc-on-inverse">
  <div class="hero__matrix" aria-hidden="true"></div>
  <div class="hero__frame" aria-hidden="true"></div>
  <div class="hero__stage" aria-hidden="true">
    <svg class="dial" viewBox="0 0 620 620" focusable="false">
      <path d="M589.6 324.7L601.6 325.3M588.5 339.3L600.4 340.5M586.6 353.8L598.4 355.7M583.9 368.2L595.6 370.7M572.7 380.4L592.1 385.6M576.3 396.5L587.7 400.2M571.4 410.3L582.6 414.6M565.8 423.9L576.8 428.8M559.5 437.1L570.2 442.6M544.8 462.5L554.9 469M536.5 474.6L546.2 481.6M527.6 486.2L536.9 493.8M518.1 497.4L527 505.4M502.3 502.3L516.5 516.5M497.4 518.1L505.4 527M486.2 527.6L493.8 536.9M474.6 536.5L481.6 546.2M462.5 544.8L469 554.9M437.1 559.5L442.6 570.2M423.9 565.8L428.8 576.8M410.3 571.4L414.6 582.6M396.5 576.3L400.2 587.7M380.4 572.7L385.6 592.1M368.2 583.9L370.7 595.6M353.8 586.6L355.7 598.4M339.3 588.5L340.5 600.4M324.7 589.6L325.3 601.6M295.3 589.6L294.7 601.6M280.7 588.5L279.5 600.4M266.2 586.6L264.3 598.4M251.8 583.9L249.3 595.6M239.6 572.7L234.4 592.1M223.5 576.3L219.8 587.7M209.7 571.4L205.4 582.6M196.1 565.8L191.2 576.8M182.9 559.5L177.4 570.2M157.5 544.8L151 554.9M145.4 536.5L138.4 546.2M133.8 527.6L126.2 536.9M122.6 518.1L114.6 527M117.7 502.3L103.5 516.5M101.9 497.4L93 505.4M92.4 486.2L83.1 493.8M83.5 474.6L73.8 481.6M75.2 462.5L65.1 469M60.5 437.1L49.8 442.6M54.2 423.9L43.2 428.8M48.6 410.3L37.4 414.6M43.7 396.5L32.3 400.2M47.3 380.4L27.9 385.6M36.1 368.2L24.4 370.7M33.4 353.8L21.6 355.7M31.5 339.3L19.6 340.5M30.4 324.7L18.4 325.3M30.4 295.3L18.4 294.7M31.5 280.7L19.6 279.5M33.4 266.2L21.6 264.3M36.1 251.8L24.4 249.3M47.3 239.6L27.9 234.4M43.7 223.5L32.3 219.8M48.6 209.7L37.4 205.4M54.2 196.1L43.2 191.2M60.5 182.9L49.8 177.4M75.2 157.5L65.1 151M83.5 145.4L73.8 138.4M92.4 133.8L83.1 126.2M101.9 122.6L93 114.6M117.7 117.7L103.5 103.5M122.6 101.9L114.6 93M133.8 92.4L126.2 83.1M145.4 83.5L138.4 73.8M157.5 75.2L151 65.1M182.9 60.5L177.4 49.8M196.1 54.2L191.2 43.2M209.7 48.6L205.4 37.4M223.5 43.7L219.8 32.3M239.6 47.3L234.4 27.9M251.8 36.1L249.3 24.4M266.2 33.4L264.3 21.6M280.7 31.5L279.5 19.6M295.3 30.4L294.7 18.4M324.7 30.4L325.3 18.4M339.3 31.5L340.5 19.6M353.8 33.4L355.7 21.6M368.2 36.1L370.7 24.4M380.4 47.3L385.6 27.9M396.5 43.7L400.2 32.3M410.3 48.6L414.6 37.4M423.9 54.2L428.8 43.2M437.1 60.5L442.6 49.8M462.5 75.2L469 65.1M474.6 83.5L481.6 73.8M486.2 92.4L493.8 83.1M497.4 101.9L505.4 93M502.3 117.7L516.5 103.5M518.1 122.6L527 114.6M527.6 133.8L536.9 126.2M536.5 145.4L546.2 138.4M544.8 157.5L554.9 151M559.5 182.9L570.2 177.4M565.8 196.1L576.8 191.2M571.4 209.7L582.6 205.4M576.3 223.5L587.7 219.8M572.7 239.6L592.1 234.4M583.9 251.8L595.6 249.3M586.6 266.2L598.4 264.3M588.5 280.7L600.4 279.5M589.6 295.3L601.6 294.7" stroke="rgba(241,239,235,.08)" stroke-width="1"/>
      <path d="M572 310L602 310M536.9 441L562.9 456M441 536.9L456 562.9M310 572L310 602M179 536.9L164 562.9M83.1 441L57.1 456M48 310L18 310M83.1 179L57.1 164M179 83.1L164 57.1M310 48L310 18M441 83.1L456 57.1M536.9 179L562.9 164" stroke="rgba(241,239,235,.22)" stroke-width="2"/>
      <circle cx="310" cy="310" r="226" fill="none" stroke="rgba(241,239,235,.07)"/>
      <path d="M31.1 199.6A300 300 0 0 1 149.3 56.7" fill="none" stroke="#f29519" stroke-width="5" stroke-linecap="round"/>
    </svg>
    <div class="walkway">
      <div class="walkway__track"></div>
      <span class="walkway__label">WIN-TRACK</span>
      <div class="step" style="left:73px;top:590px" data-step="0"></div>
      <div class="step step--r" style="left:177px;top:432px" data-step="0.6"></div>
      <div class="step" style="left:73px;top:274px" data-step="1.2"></div>
      <div class="step step--r" style="left:177px;top:116px" data-step="1.8"></div>
    </div>
  </div>
  <div class="hero__copy">
    <h1 class="hero__title">La mesure<br><span>du pas.</span></h1>
    <p class="hero__sub">Plateformes de baropodométrie et d&#39;analyse de la marche, conçues et fabriquées à Balma depuis 1985.</p>
    <div class="hero__actions">
      <a class="mc-btn mc-btn--primary mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir la gamme</a>
    </div>
  </div>
  <div class="hero__ticker">
    <span><b>2 304</b> capteurs · <b>300</b> images/s · <b>0,4 – 100</b> N</span>
    <span class="scroll">Faites défiler<span class="mc-sensor" aria-hidden="true"></span></span>
    <span>Né au <b>LAAS-CNRS</b> · fabriqué à <b>Balma</b></span>
  </div>
</section>

<section class="wrap" style="padding-bottom:56px">
  <div class="doors">
    <a class="door" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">
      <span class="door__k">PRODUITS</span>
      <h2>Je cherche une plateforme</h2>
      <p>Treize produits, de la plateforme de poche à la piste de laboratoire, comparés côte à côte.</p>
      <div class="door__thumbs" aria-hidden="true"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48"></div>
      
      <span class="door__go"><span class="mc-sensor"></span>Comparer la gamme</span>
    </a>
    <a class="door" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">
      <span class="door__k">GUIDE</span>
      <h2>Je découvre la baropodométrie</h2>
      <p>Ce que mesure une plateforme, les mots des fiches techniques, le budget à prévoir.</p>
      <div class="door__scale" aria-hidden="true"><div class="mc-pressure__bar"><i></i><i></i><i></i><i></i><i></i><i></i></div></div>
      
      <span class="door__go"><span class="mc-sensor"></span>Lire le guide · 5 min</span>
    </a>
    <a class="door door--dark" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">
      <span class="door__k">DEVIS</span>
      <h2>Je veux un devis ou une démo</h2>
      <p>Quatre questions, et votre demande arrive complète chez le bon interlocuteur.</p>
      <span class="door__tel">+33 5 62 571 571</span>
      <span class="door__go"><span class="mc-sensor"></span>Préparer ma demande · 2 min</span>
    </a>
  </div>
</section>

<section class="wrap reveal" style="padding-bottom:64px">
  <div class="sec-h"><h2 class="h2">La gamme</h2><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir les 13 produits</a></div>
  <div class="range-row">
    <a class="rp" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/">
      <div class="rp__ph"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="Minipod" width="240" height="240" loading="lazy"></div>
      <span class="rp__n">Minipod</span>
      <span class="rp__d">Mobile, sur smartphone</span>
    </a>
    <a class="rp" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/">
      <div class="rp__ph"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="T-Plate 40" width="240" height="240" loading="lazy"></div>
      <span class="rp__n">T-Plate 40 <span class="tag-new">Nouveau</span></span>
      <span class="rp__d">Le cabinet au quotidien</span>
    </a>
    <a class="rp" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/">
      <div class="rp__ph"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="Win-Pod Wifi" width="240" height="240" loading="lazy"></div>
      <span class="rp__n">Win-Pod Wifi</span>
      <span class="rp__d">Hôpital et recherche</span>
    </a>
    <a class="rp" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/">
      <div class="rp__ph"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="Fusyo" width="240" height="240" loading="lazy"></div>
      <span class="rp__n">Fusyo</span>
      <span class="rp__d">Podométrie et posturologie</span>
    </a>
    <a class="rp" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/">
      <div class="rp__ph"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="Win-Track" width="240" height="240" loading="lazy"></div>
      <span class="rp__n">Win-Track</span>
      <span class="rp__d">Analyse de la marche</span>
    </a>
  </div>
</section>

<section class="wrap reveal" style="padding-bottom:64px">
  <div class="sec-h"><h2 class="h2">Solutions</h2><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a></div>
  <div class="sol-row">
    <a class="mc-plate mc-plate--white sol-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/soft-10zones.jpg" alt="" loading="lazy"><span class="mc-product"><span class="mc-sensor"></span>Baropodométrie</span><p>La podométrie, ou baropodométrie, est l&#39;étude des pressions plantaires en statique et en dynamique.</p></a><a class="mc-plate mc-plate--white sol-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/soft-posturo.jpg" alt="" loading="lazy"><span class="mc-product"><span class="mc-sensor"></span>Posturographie</span><p>La posturologie est l&#39;étude de l&#39;équilibre orthostatique, régi par le système postural fin.</p></a><a class="mc-plate mc-plate--white sol-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/physioplay-rumble.jpg" alt="" loading="lazy"><span class="mc-product"><span class="mc-sensor"></span>Rééducation</span><p>La rééducation rassemble les techniques qui aident à réduire les déficiences et incapacités du patient liées à l&#39;équilibre orthostatique.</p></a>
    <a class="mc-plate mc-plate--white sol-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/logiciel-diabete.jpg" alt="" loading="lazy"><span class="mc-product"><span class="mc-sensor"></span>Pied diabétique</span><p>Tous les logiciels Medicapteurs intègrent une évaluation complète et simple du pied diabétique : le niveau de risque d&#39;ulcération...</p></a>
  </div>
</section>

<section style="background:var(--surface)" class="sec">
  <div class="wrap soul reveal">
    <div class="stack" style="gap:22px">
      <span class="mc-eyebrow">Depuis 1985</span>
      <h2 class="statement soul__title">Née d&#39;une peau artificielle.</h2>
      <p class="soul__text">En 1985, des chercheurs du LAAS-CNRS de Toulouse mettent au point un capteur tactile capable de sentir une pression comme la peau. Medicapteurs naît pour en faire un instrument de soin. Quarante ans plus tard, chaque plateforme est toujours conçue, assemblée et calibrée à Balma.</p>
      <div class="facts"><div><b>390+</b><span>travaux scientifiques</span></div><div><b>40</b><span>ans de capteurs</span></div><div><b>Balma</b><span>fabrication française</span></div></div>
      <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/" style="align-self:flex-start">Découvrir l&#39;entreprise</a>
    </div>
    <div class="soul__img"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/hero-plateforme.jpg" alt="Un pied posé sur une plateforme Medicapteurs" width="1600" height="1052" loading="lazy"></div>
  </div>
</section>


<section class="wrap reveal" style="padding-top:56px">
  <div class="sec-h"><h2 class="h2">Actualités</h2><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Toutes les actualités</a></div>
  <div class="news-row">
    <a class="news-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/"><time datetime="2026-11-13">13 novembre 2026</time><b>Medicapteurs à MEDICA 2026, hall 4, stand H22-1</b><span>Retrouvez-nous au plus grand salon mondial des équipements médicaux, à Düsseldorf.</span></a><a class="news-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/"><time datetime="2026-09-11">11 septembre 2026</time><b>Entretiens de Podologie à Poitiers, les 2 et 3 octobre 2026</b><span>Medicapteurs expose aux Entretiens de Podologie de la FNP.</span></a><a class="news-card" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/"><time datetime="2026-03-10">10 mars 2026</time><b>Salon AFDP 2026 : la T-Plate 40</b><span>Au Parc floral de Paris, Medicapteurs présente sa dernière née, la T-Plate « 40e anniversaire », avec le...</span></a>
  </div>
</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Essayez-la avec vos patients.</h2>
      <p>Démonstration de 30 minutes en visio, ou à votre cabinet selon votre région.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>de démonstration, en visio ou à votre cabinet</span></li><li><b>Clé en main</b><span>livraison, installation et formation en ligne</span></li><li><b>Reprise</b><span>de votre ancienne plateforme Medicapteurs</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">ou appelez-nous</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
