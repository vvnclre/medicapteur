<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Win-Pod Wifi · La plateforme de référence, des faibles pressions aux plus fortes · Medicapteurs</title>
<meta name="description" content="2 304 capteurs HD calibrés : précision, homogénéité et sensibilité. Détection des faibles pressions pour la marche de l&#39;enfant, dynamique étendue pour les fortes pressions de la course. USB sur PC, Wifi sur smartphone et tablette.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/">
<meta property="og:title" content="Win-Pod Wifi · La plateforme de référence, des faibles pressions aux plus fortes">
<meta property="og:description" content="2 304 capteurs HD calibrés : précision, homogénéité et sensibilité. Détection des faibles pressions pour la marche de l&#39;enfant, dynamique étendue pour les fortes pressions de la course. USB sur PC, Wifi sur smartphone et tablette.">
<meta property="og:locale" content="fr_FR">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-product">
<a class="skip" href="#contenu">Aller au contenu</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/fr/" aria-label="Medicapteurs, accueil">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Navigation principale">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn data-current>Produits<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>L&#39;entreprise<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Langue">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/" hreflang="fr" lang="fr" data-lang="fr" aria-current="true" class="on" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/" hreflang="en" lang="en" data-lang="en" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">Par besoin</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Examen podologique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posture et équilibre</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Analyse de la marche</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Course et sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#mobile">Mesure en déplacement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparer les modèles</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Plateformes</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 capteurs · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>Nouveau · édition des 40 ans</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4 096 capteurs · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>Nouveau · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2 304 capteurs · la référence</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Marche et sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>Piste 1 m · 2 pas</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Tapis 0,8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 capteurs libres · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Semelles 35 à 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturologie</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilométrie 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Logiciels</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Inclus avec chaque plateforme</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Vous hésitez entre deux modèles ?</strong>
        <span>Quatre questions sur votre pratique : nous vous indiquons la plateforme adaptée et son budget indicatif.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Trouver ma plateforme</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Voir toute la gamme</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Navigation principale">
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/"><span class="mc-sensor"></span>Logiciels</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
      <span class="drawer__k">L&#39;entreprise</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Assistance</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/"><span class="mc-sensor"></span>Préparer ma demande</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap p-hero">
  <div class="p-hero__copy">
    <nav class="crumbs" aria-label="Fil d’Ariane"><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">Produits</a><span aria-hidden="true">/</span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Cabinet</a><span aria-hidden="true">/</span><span aria-current="page">Win-Pod Wifi</span></nav>
    <span class="card-name"><span class="mc-product p-hero__name"><span class="mc-sensor"></span>Win-Pod Wifi</span></span>
    <h1 class="h1">La plateforme de référence, des faibles pressions aux plus fortes.</h1>
    <p class="lead">2 304 capteurs HD calibrés : précision, homogénéité et sensibilité. Détection des faibles pressions pour la marche de l&#39;enfant, dynamique étendue pour les fortes pressions de la course. USB sur PC, Wifi sur smartphone et tablette.</p>
    
    <div class="p-hero__key">
      <div class="mc-measure"><b>2 304</b><em>capteurs, matrice 48 × 48</em></div><div class="mc-measure"><b>0,4 – 100<span>N</span></b><em>par capteur</em></div><div class="mc-measure"><b>300<span>images/s</span></b><em>en dynamique</em></div>
    </div>
    
    <div class="p-hero__btns">
      <a class="mc-btn mc-btn--primary mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/?produit=win-pod-wifi"><span class="mc-sensor"></span>Demander une démo<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <a class="mc-btn mc-btn--link" href="#fiche">Voir la fiche technique</a>
    </div>
  </div>
  <div class="p-hero__media"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="Win-Pod Wifi" width="800" height="600"></div>
</section>

<nav class="subnav" aria-label="Sections de la fiche">
  <div class="wrap">
    <a href="#description">Présentation</a>
    <a href="#logiciel">Logiciel</a>
    <a href="#fiche">Caractéristiques</a>
    <a href="#documents">Documentations</a>
    <a href="#etudes">Études</a>
    <a href="#devis">Devis</a>
  </div>
</nav>

<section id="description" class="wrap sec">
  <div class="p-desc">
    <div class="prose">
      <span class="mc-eyebrow">Présentation</span>
      <p>La plateforme de référence du marché, et la garantie d&#39;une qualité de résultats made in France. Les capteurs à seuil bas conviennent à la marche de l&#39;enfant et au pied diabétique ; la grande dynamique de mesure évite la saturation aux fortes pressions, là où des appareils d&#39;entrée de gamme affichent des zones rouges surdimensionnées.</p><p>Un design novateur et des matériaux robustes, avec un positionneur et un support en Plexiglas en option. Batterie grande capacité : 2 jours d&#39;autonomie.</p>
    </div>
    <figure class="p-desc__img"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winpod-tablette.jpg" alt="Win-Pod Wifi" loading="lazy"></figure>
  </div>
  
  <div class="hl-grid">
    
    <div class="hl">
      <h2 class="h3">La plateforme</h2>
      <ul class="ticks"><li>Précision, homogénéité et sensibilité des 2 304 capteurs HD calibrés</li><li>Détection des faibles pressions pour l&#39;analyse de la marche de l&#39;enfant</li><li>Dynamique de mesure étendue pour les pressions élevées pendant la course</li><li>USB sur PC, Wifi sur smartphone et tablette iOS et Android</li></ul>
    </div>
    
    <div class="hl">
      <h2 class="h3">Le logiciel Win-Pod</h2>
      <ul class="ticks"><li>Plus de 30 années d&#39;expérience en baropodométrie</li><li>Prise en main aisée, du débutant à l&#39;expert</li><li>Analyse statique, dynamique et posturale</li><li>Bilans imprimables ou en PDF, comparaison avant / après traitement</li><li>Fonctions avancées pour la recherche, export statistique</li><li>Plus de 150 publications scientifiques et mémoires</li></ul>
    </div>
    
  </div>
  
</section>


<section id="logiciel" class="dark-sec mc-on-inverse sec">
  <div class="wrap soft">
    <div class="soft__head">
      <span class="mc-eyebrow">Logiciel Medicapteurs</span>
      <h2 class="h2">Win-Pod software · V10</h2>
      <p class="soft__intro">Le logiciel Win-Pod pour Windows est le résultat de plus de 30 années d&#39;expérience en baropodométrie. Il s&#39;adresse autant au débutant qu&#39;à l&#39;expert et à la recherche.</p>
      <p class="soft__note">Les logiciels Medicapteurs fonctionnent hors ligne : les données patients restent chez vous, sans serveur cloud.</p>
    </div>
    
    <div class="soft__groups">
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Acquisition</span><ul class="ticks ticks--dark"><li>Acquisition multi-pas</li><li>Enregistrement jusqu&#39;à 300 images par seconde</li><li>Synchronisation automatique jusqu&#39;à 2 caméras vidéo</li></ul></div>
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Analyse</span><ul class="ticks ticks--dark"><li>Visualisations thermographique, isopression, pourcentage, 3D</li><li>Analyse automatique par 2, 7, 10 ou 12 zones</li><li>Découpage libre : dissymétrie, retard pied gauche / pied droit</li><li>Analyse médio-latérale</li><li>Sway index : papillon du centre de pression</li></ul></div>
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Indices</span><ul class="ticks ticks--dark"><li>Foot Posture Index, normalisation internationale du pied</li><li>CPEI : type de pied pronateur, supinateur ou normal calculé automatiquement</li><li>Rapport pied diabétique automatique</li></ul></div>
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Rapport et partage</span><ul class="ticks ticks--dark"><li>Impression à l&#39;échelle 1:1</li><li>Tout type de fichier rattaché à l&#39;examen (Word, JPEG, PDF)</li><li>Envoi du rapport par e-mail en 2 clics</li><li>Export pour analyse statistique</li></ul></div>
      
    </div>
    
    <img class="shot" src="<?php echo esc_url( MC_URI ); ?>/assets/img/soft-dynamiq.jpg" alt="Logiciel Medicapteurs : rapport pied diabétique avec niveau de risque et zones à décharger" width="1400" height="788" loading="lazy">
  </div>
</section>


<section id="fiche" class="wrap sec">
  <div class="sec-h"><div><span class="mc-eyebrow">Caractéristiques</span><h2 class="h2">Fiche technique Win-Pod Wifi</h2></div></div>
  
  <div class="spec-grid">
    
    <table class="mc-spec">
      <caption>Mécanique</caption>
      <tr><th scope="row">Dimensions</th><td>530 × 610 × 25 mm <span class="check">à confirmer</span></td></tr><tr><th scope="row">Épaisseur</th><td>4 mm</td></tr><tr><th scope="row">Poids</th><td>6,8 kg <span class="check">à confirmer</span></td></tr><tr><th scope="row">Surface active</th><td>400 × 400 mm</td></tr>
    </table>
    
    <table class="mc-spec">
      <caption>Électronique</caption>
      <tr><th scope="row">Capteurs</th><td>2 304 (48 × 48), résistifs calibrés</td></tr><tr><th scope="row">Taille, épaisseur du capteur</th><td>8 × 8 mm · 0,15 mm</td></tr><tr><th scope="row">Pression par capteur</th><td>0,4 à 100 N</td></tr><tr><th scope="row">Fréquence</th><td>jusqu&#39;à 300 images/s (standard ou option ?) <span class="check">à confirmer</span></td></tr><tr><th scope="row">Température</th><td>-40 – 85 °C</td></tr><tr><th scope="row">Connexion</th><td>USB · Wifi (iOS, Android avec Podocapture)</td></tr><tr><th scope="row">Alimentation</th><td>USB ou batterie lithium, 2 jours d&#39;autonomie</td></tr><tr><th scope="row">Système</th><td>Windows 8, 10, 11</td></tr>
    </table>
    
    
    <div class="opts-box">
      <span class="mc-eyebrow">Options</span>
      <ul class="ticks"><li>Positionneur Plexiglas</li><li>Support Plexiglas</li><li>Valise de transport</li><li>Logiciel Physioplay (rééducation)</li></ul>
    </div>
    
  </div>
  <p class="note" style="margin-top:16px">Caractéristiques issues des fiches et brochures Medicapteurs. Les valeurs signalées « à confirmer » diffèrent entre deux documents et sont en cours de validation.</p>
  
</section>


<section id="documents" class="wrap" style="padding-bottom:48px">
  <span class="mc-eyebrow" style="margin-bottom:14px">Documentations</span>
  <div class="docs"><a class="doc" href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2017/02/win-pod_2022.pdf" target="_blank" rel="noopener"><span class="doc__ic" aria-hidden="true">PDF</span><span>Brochure Win-Pod 2022 (PDF)</span></a><a class="doc" href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2017/08/documentation_winpod_wifi-.pdf" target="_blank" rel="noopener"><span class="doc__ic" aria-hidden="true">PDF</span><span>Documentation Win-Pod Wifi (PDF)</span></a><a class="doc" href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2017/02/podocapture-uk.pdf" target="_blank" rel="noopener"><span class="doc__ic" aria-hidden="true">PDF</span><span>Application Podocapture (PDF)</span></a></div>
</section>


<section id="devis" class="wrap" style="padding-bottom:56px">
  <div class="quote">
    <div class="quote__t"><strong>Demander un devis pour Win-Pod Wifi</strong><span>Plateforme, logiciel et application inclus, livraison, installation et formation en ligne. Reprise possible de votre ancienne plateforme Medicapteurs.</span></div>
    <div class="quote__price">
      <small>Prix catalogue 2024 indicatif</small><b>8 319 € TTC</b><small><span class="check">à confirmer</span></small>
      
    </div>
    <a class="mc-btn mc-btn--primary" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/?produit=win-pod-wifi"><span class="mc-sensor"></span>Préparer ma demande</a>
  </div>
</section>


<section id="etudes" class="sec sec--alt">
  <div class="wrap"><div class="sec-h" style="margin:0;align-items:center">
    <div><span class="mc-eyebrow">Études</span><p class="h2"><span class="num">94</span> travaux scientifiques publiés avec ce produit</p></div>
    <a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/"><span class="mc-sensor"></span>Voir les études</a>
  </div></div>
</section>



<section class="wrap sec">
  <span class="mc-eyebrow" style="margin-bottom:16px">Souvent comparé avec</span>
  
<div class="related">
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">T-Plate</span><small>1 600 capteurs · USB, Wifi</small></span></a>
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Fusyo</span><small>Podo + stabilométrie APE</small></span></a>
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Win-Track</span><small>Piste 1,5 m · 200 images/s</small></span></a>
  
</div>

</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plateformes de mesure des pressions plantaires, conçues et fabriquées à Balma depuis 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Produits</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#cabinet">Plateformes</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#labo">Pistes de marche</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#posture">Posturologie</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/w-inshoe/">Capteurs embarqués</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/logiciels/">Logiciels</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/#comparateur">Comparateur</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/baropodometrie/">Baropodométrie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/posturographie/">Posturographie</a><a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">Rééducation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/pied-diabetique/">Pied diabétique</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/ingenierie/">Ingénierie sur mesure</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Ressources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/comprendre-la-mesure/">Comprendre la mesure</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">Études</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/telechargements/">Téléchargements</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">Support et hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">Actualités</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Entreprise</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/entreprise/">Notre histoire</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">Préparer ma demande</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Dispositifs médicaux. Classe, règlement et organisme notifié : à préciser par Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/">Mentions légales</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/fr/mentions-legales/#donnees">Données personnelles</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
