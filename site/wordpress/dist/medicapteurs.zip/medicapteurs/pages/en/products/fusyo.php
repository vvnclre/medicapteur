<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fusyo · Podometry and stabilometry on a single platform · Medicapteurs</title>
<meta name="description" content="The new Fusyo 3, wired or with built-in Wi-Fi: a 2,304-sensor matrix for podometry and three strain gauges for stabilometry following the recommendations of the French Posture and Balance Association (APE).">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/">
<meta property="og:title" content="Fusyo · Podometry and stabilometry on a single platform">
<meta property="og:description" content="The new Fusyo 3, wired or with built-in Wi-Fi: a 2,304-sensor matrix for podometry and three strain gauges for stabilometry following the recommendations of the French Posture and Balance Association (APE).">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-product">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn data-current>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/produits/fusyo/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap p-hero">
  <div class="p-hero__copy">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a><span aria-hidden="true">/</span><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a><span aria-hidden="true">/</span><span aria-current="page">Fusyo</span></nav>
    <span class="card-name"><span class="mc-product p-hero__name"><span class="mc-sensor"></span>Fusyo</span></span>
    <h1 class="h1">Podometry and stabilometry on a single platform.</h1>
    <p class="lead">The new Fusyo 3, wired or with built-in Wi-Fi: a 2,304-sensor matrix for podometry and three strain gauges for stabilometry following the recommendations of the French Posture and Balance Association (APE).</p>
    
    <div class="p-hero__key">
      <div class="mc-measure"><b>2,304</b><em>sensors + 3 gauges</em></div><div class="mc-measure"><b>5 – 40<span>Hz</span></b><em>stabilometry</em></div><div class="mc-measure"><b>250<span>kg</span></b><em>maximum load</em></div>
    </div>
    
    <div class="p-hero__btns">
      <a class="mc-btn mc-btn--primary mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/?produit=fusyo"><span class="mc-sensor"></span>Request a demo<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <a class="mc-btn mc-btn--link" href="#fiche">See the specifications</a>
    </div>
  </div>
  <div class="p-hero__media"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="Fusyo" width="800" height="600"></div>
</section>

<nav class="subnav" aria-label="Page sections">
  <div class="wrap">
    <a href="#description">Overview</a>
    <a href="#logiciel">Software</a>
    <a href="#fiche">Specifications</a>
    <a href="#documents">Documentation</a>
    <a href="#etudes">Studies</a>
    <a href="#devis">Quote</a>
  </div>
</nav>

<section id="description" class="wrap sec">
  <div class="p-desc">
    <div class="prose">
      <span class="mc-eyebrow">Overview</span>
      <p>Fusyo, a unique combination: Medicapteurs makes a system that brings together an electronic podometry platform and a posturography platform following APE recommendations.</p><p>Fusyo software uses every feature of the Win-Pod and Win-Posture NV software. It also opens new analyses of stabilometric parameters correlated with static baropodometry.</p>
    </div>
    <figure class="p-desc__img"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo-plateau.jpg" alt="Fusyo" loading="lazy"></figure>
  </div>
  
  <div class="hl-grid">
    
    <div class="hl">
      <h2 class="h3">Podometry features</h2>
      <ul class="ticks"><li>Highly accurate and reliable pressure maps</li><li>All Win-Pod software features</li></ul>
    </div>
    
    <div class="hl">
      <h2 class="h3">Posturography features</h2>
      <ul class="ticks"><li>Postural assessment, static and balance disorders</li><li>Following AFP85 (SOFPEL) recommendations, now APE</li></ul>
    </div>
    
  </div>
  
</section>


<section id="logiciel" class="dark-sec mc-on-inverse sec">
  <div class="wrap soft">
    <div class="soft__head">
      <span class="mc-eyebrow">Medicapteurs software</span>
      <h2 class="h2">Fusyo software</h2>
      <p class="soft__intro">User-friendly software that brings podometry and posturography together. The report is fully customisable to your way of working: photos, comments, templates, batch printing.</p>
      <p class="soft__note">Medicapteurs software works offline: patient data stays with you, with no cloud server.</p>
    </div>
    
    <div class="soft__groups">
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Static analysis</span><ul class="ticks ticks--dark"><li>Static mapping with zone calculation</li><li>Thermographic, isopressure, percentage and 3D views</li><li>1:1 scale printing</li><li>Examination comparison</li><li>Foot Posture Index</li></ul></div>
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Dynamic analysis (with a walkway, not supplied)</span><ul class="ticks ticks--dark"><li>Multi-step acquisition up to 200 frames per second</li><li>Global dynamic image, calculations, curves</li><li>Mosaic of stance phases, zone analysis</li><li>Contact time and load</li><li>Automatically synchronised video</li><li>Medio-lateral analysis, CPEI</li><li>Diabetic foot report</li></ul></div>
      
      <div><span class="mc-product soft__k"><span class="mc-sensor"></span>Win-Posture NV: static and dynamic stabilography</span><ul class="ticks ticks--dark"><li>Creation and management of acquisition protocols</li><li>Norms and reference settings</li><li>All AFP85 (APE) standardised stabilometry data</li><li>Options: wavelets, fractal and diffusion analysis</li><li>Examination comparison</li><li>Multiple views of the stabilometric signal</li><li>Customisable reports</li><li>Direct export to Excel</li><li>Letter editor, mail merge</li></ul></div>
      
    </div>
    
    <img class="shot" src="<?php echo esc_url( MC_URI ); ?>/assets/img/soft-dynamiq.jpg" alt="Medicapteurs software: diabetic foot report with risk level and areas to offload" width="1400" height="788" loading="lazy">
  </div>
</section>


<section id="fiche" class="wrap sec">
  <div class="sec-h"><div><span class="mc-eyebrow">Specifications</span><h2 class="h2">Data sheet Fusyo</h2></div></div>
  
  <div class="spec-grid">
    
    <table class="mc-spec">
      <caption>Mechanical</caption>
      <tr><th scope="row">Dimensions</th><td>530 × 600 × 70 mm <span class="check">to be confirmed</span></td></tr><tr><th scope="row">Thickness</th><td>35 mm</td></tr><tr><th scope="row">Weight</th><td>12.5 kg</td></tr>
    </table>
    
    <table class="mc-spec">
      <caption>Electronics</caption>
      <tr><th scope="row">Active area</th><td>400 × 400 mm</td></tr><tr><th scope="row">Maximum load</th><td>250 kg</td></tr><tr><th scope="row">Sensors</th><td>2.304 (48 × 48) high-resolution for podometry · 3 strain gauges for stabilometry</td></tr><tr><th scope="row">Sensor size, thickness</th><td>8 × 8 mm · 0.15 mm</td></tr><tr><th scope="row">Pressure per sensor</th><td>0.4 to 100 N</td></tr><tr><th scope="row">Non-linearity</th><td>&lt; 0.2 %</td></tr><tr><th scope="row">Sampling rate</th><td>Podometry 200 frames/s · stabilometry 5 or 40 Hz <span class="check">to be confirmed</span></td></tr><tr><th scope="row">Connection</th><td>USB · Wi-Fi</td></tr><tr><th scope="row">Power</th><td>USB cable, battery in Wi-Fi mode (supplied or not?) <span class="check">to be confirmed</span></td></tr><tr><th scope="row">Operating system</th><td>Windows 7, 8, 10, 11</td></tr>
    </table>
    
    
    <div class="opts-box">
      <span class="mc-eyebrow">Options</span>
      <ul class="ticks"><li>Dynamic balance board</li><li>Carrying case</li><li>Win-Trainer NV (rehabilitation)</li></ul>
    </div>
    
  </div>
  <p class="note" style="margin-top:16px">Specifications from Medicapteurs data sheets and brochures. Values marked “to be confirmed” differ between two documents and are being validated.</p>
  
</section>


<section id="documents" class="wrap" style="padding-bottom:48px">
  <span class="mc-eyebrow" style="margin-bottom:14px">Documentation</span>
  <div class="docs"><a class="doc" href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2017/02/fusyo-v3-2019.pdf" target="_blank" rel="noopener"><span class="doc__ic" aria-hidden="true">PDF</span><span>New Fusyo brochure (PDF)</span></a><a class="doc" href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2017/02/documentation-fusyo.pdf" target="_blank" rel="noopener"><span class="doc__ic" aria-hidden="true">PDF</span><span>Fusyo documentation (PDF)</span></a></div>
</section>


<section id="devis" class="wrap" style="padding-bottom:56px">
  <div class="quote">
    <div class="quote__t"><strong>Request a quote for Fusyo</strong><span>Platform, software and app included, delivery, installation and online training. Trade-in of your old Medicapteurs platform possible.</span></div>
    <div class="quote__price">
      <b style="font-size:20px">Price on request</b>
    </div>
    <a class="mc-btn mc-btn--primary" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/?produit=fusyo"><span class="mc-sensor"></span>Prepare my request</a>
  </div>
</section>


<section id="etudes" class="sec sec--alt">
  <div class="wrap"><div class="sec-h" style="margin:0;align-items:center">
    <div><span class="mc-eyebrow">Studies</span><p class="h2"><span class="num">84</span> scientific papers published with this product</p></div>
    <a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/"><span class="mc-sensor"></span>See the studies</a>
  </div></div>
</section>



<section class="wrap sec">
  <span class="mc-eyebrow" style="margin-bottom:16px">Often compared with</span>
  
<div class="related">
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
  
</div>

</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
