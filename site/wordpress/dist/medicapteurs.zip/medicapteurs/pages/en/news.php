<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>News: trade shows, new products, offers · Medicapteurs</title>
<meta name="description" content="Medicapteurs news: MEDICA, AFDP, FNP trade shows, podiatry congresses, product launches.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/news/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/news/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/">
<meta property="og:title" content="News: trade shows, new products, offers">
<meta property="og:description" content="Medicapteurs news: MEDICA, AFDP, FNP trade shows, podiatry congresses, product launches.">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-news">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn data-current>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/actualites/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">

<section class="wrap page-head">
  <span class="mc-eyebrow">News</span>
  <h1 class="h1 statement page-head__statement">News.</h1>
  <p class="lead">Medicapteurs trade shows, new products and events.</p>
</section>

<section class="wrap" style="padding-bottom:56px">
  <ol class="news">
    <li class="news__it">
      <time datetime="2026-11-13">13 November 2026</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">Meet us at MEDICA 2026, Hall 4, Stand H22-1</h2><p>Meet us at the world&#39;s largest medical equipment show, in Düsseldorf.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2026-09-11">11 September 2026</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">Podiatry congress in Poitiers, 2 and 3 October 2026</h2><p>Medicapteurs exhibits at the FNP podiatry congress.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2026-03-10">10 March 2026</time>
      <div class="news__body"><span class="mc-eyebrow">New product</span><h2 class="h3">AFDP 2026: T-Plate 40</h2><p>At the Parc floral in Paris, Medicapteurs presents its latest platform, the “40th anniversary” T-Plate, with the full-option software and its automatically generated summary report.</p><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/">T-Plate 40</a></div>
      
    </li>
    <li class="news__it">
      <time datetime="2025-02-26">26 February 2025</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">Salon de Podologie, 7 and 8 March 2025 in Paris</h2><p>Come and ask your questions and see our demonstrations. Talk: “Minipod: pressure plates for everyone!”.</p><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/">Minipod</a></div>
      
    </li>
    <li class="news__it">
      <time datetime="2024-11-19">19 November 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">FNP 2024 in Paris, 22 and 23 November</h2><p>Meet us on our stand at the French national podiatry federation show. Free entry.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2024-11-14">14 November 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">MEDICA 2024, Hall 4, Stand H06-2</h2><p>Every year, Medicapteurs attends the world&#39;s largest medical equipment show, 11 to 14 November 2024.</p></div>
      <img class="news__img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/medica-stand.jpg" alt="" loading="lazy">
    </li>
    <li class="news__it">
      <time datetime="2024-02-23">23 February 2024</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">Salon de la Podologie, 8 and 9 March 2024 in Paris</h2><p>At the Parc floral in Paris, stand 4, to discover Minipod and the whole range.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2024-01-08">8 January 2024</time>
      <div class="news__body"><span class="mc-eyebrow">New product</span><h2 class="h3">PowerTrack, the smart treadmill</h2><p>A treadmill fitted with removable pressure sensors to study athletes, walking and running; a walkway for children and older people, laid on the floor in 5 seconds.</p><a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/">PowerTrack</a></div>
      
    </li>
    <li class="news__it">
      <time datetime="2023-09-28">28 September 2023</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">MEDICA 2023, Booth 4H06</h2><p>Medicapteurs exhibits at MEDICA 2023.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2022-11-25">25 November 2022</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">ISPO 2022 in Munich</h2><p>Booth A3/426: our latest technology for sports shops.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2022-04-14">14 April 2022</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">OT World, Hall 1, Booth 36</h2><p>Medicapteurs at the international orthopaedic technology show in Leipzig.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2021-02-22">22 February 2021</time>
      <div class="news__body"><span class="mc-eyebrow">Event</span><h2 class="h3">Open day on 18 March 2021</h2><p>A day of online demonstrations, free with registration.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2020-11-16">16 November 2020</time>
      <div class="news__body"><span class="mc-eyebrow">Event</span><h2 class="h3">Virtual stand on 19 November 2020</h2><p>Online demonstrations of the whole range.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2020-04-06">6 April 2020</time>
      <div class="news__body"><span class="mc-eyebrow">Training</span><h2 class="h3">Medicapteurs webinars</h2><p>A webinar schedule by platform, with Marc Janin, podiatrist PhD.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2019-10-17">17 October 2019</time>
      <div class="news__body"><span class="mc-eyebrow">Software</span><h2 class="h3">The automatic diabetic foot report</h2><p>Ulceration risk level (forefoot / rearfoot ratio, David Armstrong&#39;s publication), risk zone location, foot type. On Win-Pod, Win-Track, Win-Track Mini and Fusyo.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2019-09-02">2 September 2019</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">44th Podiatry congress in Paris, 4 and 5 October 2019</h2><p>Meet Medicapteurs in early October in Paris.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-11-26">26 November 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Trade show</span><h2 class="h3">Rehacare and Orthopedic China 2019 in Guangzhou</h2><p>Medicapteurs exhibits in China.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-08-29">29 August 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Event</span><h2 class="h3">Digital innovation day, Montpellier</h2><p>On 19 September 2018.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-03-15">15 March 2018</time>
      <div class="news__body"><span class="mc-eyebrow">New product</span><h2 class="h3">Podocapture, the first mobile app to drive a Wi-Fi platform</h2><p>Free on the App Store and Google Play, for Win-Pod Wifi and T-Plate Wifi.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2018-01-11">11 January 2018</time>
      <div class="news__body"><span class="mc-eyebrow">Congress</span><h2 class="h3">SOFAMEA congress in Toulouse · International posturology days in Madrid</h2><p>Medicapteurs at the 17th congress of the French-speaking society for movement analysis in children and adults, then in Madrid from 26 to 28 January 2018.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2017-02-14">14 February 2017</time>
      <div class="news__body"><span class="mc-eyebrow">Training</span><h2 class="h3">Baropodometry master class with Marc Janin, PhD</h2><p>From 23 to 25 February 2017, three days of master class at Medicapteurs.</p></div>
      
    </li>
    <li class="news__it">
      <time datetime="2017-01-01">1 January 2017</time>
      <div class="news__body"><span class="mc-eyebrow">New product</span><h2 class="h3">Medicapteurs launches Physioplay</h2><p>Playful visual-postural rehabilitation for everyone.</p></div>
      
    </li>
  </ol>
</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Try it with your own patients.</h2>
      <p>A 30-minute video demo, or at your practice depending on your region.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>of demo, by video or at your practice</span></li><li><b>Turnkey</b><span>delivery, installation and online training</span></li><li><b>Trade-in</b><span>of your old Medicapteurs platform</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">or call us</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
