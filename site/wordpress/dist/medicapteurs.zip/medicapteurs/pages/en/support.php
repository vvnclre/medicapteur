<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Support: hotline, licence, FAQ, PC requirements · Medicapteurs</title>
<meta name="description" content="Medicapteurs hotline, licence code registration, frequently asked questions, PC requirements and manuals.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/support/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/support/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/">
<meta property="og:title" content="Support: hotline, licence, FAQ, PC requirements">
<meta property="og:description" content="Medicapteurs hotline, licence code registration, frequently asked questions, PC requirements and manuals.">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-support">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn data-current>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/assistance/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">

<section class="wrap page-head">
  <span class="mc-eyebrow">Support</span>
  <h1 class="h1 statement page-head__statement">You already have our equipment.</h1>
  <p class="lead">A question, a problem or a suggestion about your software? Here is how to get help.</p>
</section>

<section class="wrap" style="padding-bottom:48px">
  <div class="hotline">
    <div class="stack" style="gap:8px"><span class="mc-eyebrow">Hotline</span><a class="hotline__tel" href="tel:+33562577459">+33 5 62 577 459</a><span>Monday to Friday, 9 am – 12 pm and 2 pm – 5 pm <span class="check">Hours to be confirmed (5 pm or 6 pm)</span></span><span class="muted">Have the software name, its version number and your platform&#39;s serial number ready.</span></div>
    <div class="stack" style="gap:8px"><span class="mc-eyebrow">E-mail</span><span class="hotline__mail">sav@medicapteurs.fr</span><span class="muted">After-sales department, Balma</span></div>
  </div>
  <div class="tiles" style="margin-top:20px">
    <div class="tile"><b>Licence code</b><span>To register your licence, open the Medicapteurs software, Help menu then About, and copy the 25 characters on a red background. Send them to the after-sales department with the equipment name and serial number, the software name (Win-Pod / Win-Track / Fusyo, Win-Posture, Win-Trainer) and its version (V1 to V10).</span></div><div class="tile"><b>Remote assistance</b><span>A technician can take control of your PC during the hotline call.</span></div><div class="tile"><b>Manuals</b><span>Manuals are on the installation CD, in the “Manuals” folder, and in the customer area sav.medicapteurs.fr.</span></div>
    <a class="tile tile--link" href="<?php echo esc_url( MC_HOME ); ?>/en/software/#configuration"><b>PC requirements</b><span>Windows 8.1, 10, 11 · 8 GB / 16 GB</span></a>
  </div>
</section>
<section class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">FAQ</span><h2 class="h2">Frequently asked questions</h2></div></div>
    <div class="faq"><details open><summary>How do I change computer?</summary><p>First back up your current database so you can transfer it. Check the recommended PC configuration, then contact us to confirm the new computer is compatible with your Medicapteurs product.</p></details><details><summary>How do I back up?</summary><p>Copy the “data” folder located in your Medicapteurs software folder, on your hard drive. Do it at least twice a week to lose as little data as possible if your computer fails.</p></details><details><summary>What is the difference between the Win-Pod posturography option and a standardised stabilometry platform?</summary><p>Since 1985, a French standard from the French Posturology Association, now the Posture and Balance Association (APE), has set very precise specifications for stabilometry platforms, so that they give the same results and refer to the same numerical norm. Fusyo and Win-Posturo meet it.</p></details><details><summary>How do I clean the platform?</summary><p>With alcohol-free cleaning wipes for plastic surfaces, such as Phagolingettes.</p></details><details><summary>I have lost my manual.</summary><p>Manuals are available electronically on your installation CD, in the “Manuals” folder. The after-sales department can also send them to you.</p></details><details><summary>Can I measure a patient wearing shoes?</summary><p>Yes, all platforms allow it. Check that nothing sharp is stuck in the soles and avoid stiletto heels.</p></details><details><summary>Is my patient data sent over the internet?</summary><p>No. Medicapteurs software works offline: there is no connection to a cloud server.</p></details><details><summary>Can I trade in my old platform?</summary><p>Yes, Medicapteurs offers to take back your old Medicapteurs platform, whatever its condition, when you buy new equipment. Amount depends on the current offer.</p></details></div>
  </div>
</section>
<section class="wrap sec">
  <div class="quote"><div class="quote__t"><strong>Downloads</strong><span>Product documentation, PC requirements and publication lists, in PDF.</span></div><a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/"><span class="mc-sensor"></span>Downloads</a></div>
</section>

</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
