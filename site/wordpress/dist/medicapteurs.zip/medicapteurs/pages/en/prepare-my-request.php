<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Prepare my quote or demo request · Medicapteurs</title>
<meta name="description" content="Four questions about your practice: Medicapteurs points you to the right platform and your request reaches the right person, complete.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/">
<meta property="og:title" content="Prepare my quote or demo request">
<meta property="og:description" content="Four questions about your practice: Medicapteurs points you to the right platform and your request reaches the right person, complete.">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-request">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/preparer-ma-demande/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap page-head" style="padding-bottom:8px">
  <span class="mc-eyebrow">2 minutes · no commitment</span>
  <h1 class="h1">Prepare my request</h1>
  <p class="lead">Answer four questions: we point you to the right platform and your request reaches the right person, complete.</p>
</section>

<section class="wrap" style="padding-bottom:64px">
  <form class="req" data-req novalidate data-to="export@medicapteurs.fr">
    <div>
      <fieldset class="req__q">
        <legend><span class="req__n">1/4</span>What is your profession?</legend>
        <div class="opts"><label class="opt"><input type="radio" name="metier" value="podo" data-label="Podiatrist" checked><span>Podiatrist</span></label><label class="opt"><input type="radio" name="metier" value="medecin" data-label="Doctor, diabetologist"><span>Doctor, diabetologist</span></label><label class="opt"><input type="radio" name="metier" value="kine" data-label="Physiotherapist, rehabilitation"><span>Physiotherapist, rehabilitation</span></label><label class="opt"><input type="radio" name="metier" value="chercheur" data-label="Researcher"><span>Researcher</span></label><label class="opt"><input type="radio" name="metier" value="sport" data-label="Sport"><span>Sport</span></label><label class="opt"><input type="radio" name="metier" value="pharma" data-label="Pharmacy, orthotics"><span>Pharmacy, orthotics</span></label><label class="opt"><input type="radio" name="metier" value="autre" data-label="Other"><span>Other</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend><span class="req__n">2/4</span>What do you want to measure?<small>Several answers possible.</small></legend>
        <div class="opts"><label class="opt"><input type="checkbox" name="usage" value="statique" data-label="Static" checked><span>Static</span></label><label class="opt"><input type="checkbox" name="usage" value="pas" data-label="One step" checked><span>One step</span></label><label class="opt"><input type="checkbox" name="usage" value="marche" data-label="Several steps"><span>Several steps</span></label><label class="opt"><input type="checkbox" name="usage" value="course" data-label="Running"><span>Running</span></label><label class="opt"><input type="checkbox" name="usage" value="posture" data-label="Posture and balance"><span>Posture and balance</span></label><label class="opt"><input type="checkbox" name="usage" value="chaussure" data-label="Inside the shoe"><span>Inside the shoe</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend><span class="req__n">3/4</span>Where will you use it?</legend>
        <div class="opts"><label class="opt"><input type="radio" name="lieu" value="cabinet" data-label="In my practice" checked><span>In my practice</span></label><label class="opt"><input type="radio" name="lieu" value="mobile" data-label="On the move"><span>On the move</span></label><label class="opt"><input type="radio" name="lieu" value="labo" data-label="In a laboratory"><span>In a laboratory</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend><span class="req__n">4/4</span>What would you like to receive?<small>Several answers possible.</small></legend>
        <div class="opts"><label class="opt"><input type="checkbox" name="suite" value="demo" data-label="A demo" checked><span>A demo</span></label><label class="opt"><input type="checkbox" name="suite" value="devis" data-label="A quote" checked><span>A quote</span></label><label class="opt"><input type="checkbox" name="suite" value="reprise" data-label="A trade-in of my old platform"><span>A trade-in of my old platform</span></label><label class="opt"><input type="checkbox" name="suite" value="doc" data-label="Documentation"><span>Documentation</span></label></div>
      </fieldset>
      <fieldset class="req__q">
        <legend>Your details</legend>
        <div class="fields">
          <div class="fld"><label for="r-name">Full name</label><input id="r-name" name="name" autocomplete="name" required aria-describedby="r-name-err"><span class="err" id="r-name-err" hidden>Please enter your name so we know who to call back.</span></div>
          <div class="fld"><label for="r-city">City and country</label><input id="r-city" name="city" autocomplete="address-level2"></div>
          <div class="fld"><label for="r-email">Email</label><input id="r-email" name="email" type="email" autocomplete="email" required aria-describedby="r-email-err"><span class="err" id="r-email-err" hidden>Please enter a full email address, for example name@clinic.com.</span></div>
          <div class="fld"><label for="r-tel">Phone <small>(optional)</small></label><input id="r-tel" name="tel" type="tel" autocomplete="tel"></div>
          <div class="fld fld--full"><label for="r-msg">Details <small>(optional)</small></label><textarea id="r-msg" name="msg" rows="3" placeholder="For example: I would like to see the diabetic foot report on a patient."></textarea></div>
        </div>
      </fieldset>
    </div>

    <aside class="req__side" aria-live="polite">
      <div class="reco">
        <span class="mc-eyebrow">Our recommendation</span>
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" data-reco-img width="400" height="250">
        <span data-reco-names><span class="mc-product"><span class="mc-sensor"></span>T-Plate</span></span>
        <p data-reco-why></p>
        <span class="reco__price">Indicative budget : <span data-reco-price>Price on request</span></span>
      </div>
      <div class="recap">
        <span class="mc-eyebrow" style="margin-bottom:12px">Your request</span>
        <dl>
          <dt>Profession</dt><dd data-r="metier"></dd>
          <dt>Measurements</dt><dd data-r="usage"></dd>
          <dt>Setting</dt><dd data-r="lieu"></dd>
          <dt>To receive</dt><dd data-r="suite"></dd>
          <dt>Sent to</dt><dd data-r="to">Export department, Balma</dd>
        </dl>
      </div>
      <div class="req__send">
        <button class="mc-btn mc-btn--primary mc-btn--lg" type="submit"><span class="mc-sensor"></span>Send my request<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></button>
        <span class="note">Your email app opens with the request already written: you just have to send it. Your data is only used to reply to you.</span>
        <div class="req__done" data-done hidden>Your email app has opened. If nothing happened, write to us at <a href="mailto:export@medicapteurs.fr">export@medicapteurs.fr</a>.</div>
        <span class="note">Prefer to talk to someone? Call <a href="tel:+33562571571" style="font-family:var(--font-mono)">+33 5 62 571 571</a>.</span>
      </div>
    </aside>
  </form>
</section>

<script type="application/json" id="mc-products">{"minipod": {"name": "Minipod", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg", "price": "€1,790 incl. VAT"}, "t-plate": {"name": "T-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg", "price": null}, "t-plate-40": {"name": "T-Plate 40", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg", "price": null}, "t-plate-30th": {"name": "T-Plate 30th", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg", "price": null}, "xt-plate": {"name": "XT-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg", "price": null}, "win-pod-wifi": {"name": "Win-Pod Wifi", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg", "price": "€8,319 incl. VAT"}, "fusyo": {"name": "Fusyo", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg", "price": null}, "win-posturo": {"name": "Win-Posturo", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg", "price": null}, "win-track": {"name": "Win-Track", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg", "price": "€12,388 incl. VAT"}, "win-track-mini": {"name": "Win-Track Mini", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg", "price": "€9,925 incl. VAT"}, "powertrack": {"name": "PowerTrack", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg", "price": null}, "w-inshoe": {"name": "W-Inshoe", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg", "price": "€3,495 incl. VAT"}, "w-inshoe-easy": {"name": "W-Inshoe Easy", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg", "price": "€5,600 incl. VAT"}}</script>

<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/reco.js"></script>
<script>
(function () {
  var f = document.querySelector("[data-req]");
  var data = JSON.parse(document.getElementById("mc-products").textContent);
  var lang = document.documentElement.lang;
  var T = {
    toDefine: "to be specified", onRequest: "Price on request",
    subject: "Request from the website", reco: "Our recommendation",
    labels: { metier: "Profession", usage: "Measurements", lieu: "Setting", suite: "To receive", name: "Full name", city: "City and country", email: "Email", tel: "Phone", msg: "Details" },
    toPosturo: "Posturology office, Sophia Antipolis", toDefault: "Export department, Balma"
  };
  /* Réponses reprises de la page précédente (comparateur, fiche produit) */
  var q = new URLSearchParams(location.search);
  if (q.get("metier")) f.querySelectorAll('[name=metier]').forEach(function (i) { i.checked = i.value === q.get("metier"); });
  if (q.get("lieu")) f.querySelectorAll('[name=lieu]').forEach(function (i) { i.checked = i.value === q.get("lieu"); });
  if (q.get("usage")) f.querySelectorAll('[name=usage]').forEach(function (i) { i.checked = i.value === q.get("usage"); });
  var wanted = q.get("produit") && data[q.get("produit")] ? q.get("produit") : null;

  function picked(name) { return Array.prototype.filter.call(f.querySelectorAll('[name=' + name + ']'), function (i) { return i.checked; }); }
  function labels(name) { var l = picked(name).map(function (i) { return i.getAttribute("data-label"); }); return l.length ? l.join(", ") : T.toDefine; }
  var current;
  function update() {
    var s = { metier: (picked("metier")[0] || {}).value, usages: picked("usage").map(function (i) { return i.value; }), lieu: (picked("lieu")[0] || {}).value };
    var r = window.mcReco(s, lang);
    var slugs = wanted ? [wanted] : r.slugs;
    current = slugs;
    f.querySelector("[data-reco-names]").innerHTML = slugs.map(function (k) { return '<a class="mc-product" href="' + data[k].url + '"><span class="mc-sensor"></span>' + data[k].name + "</a>"; }).join(" · ");
    f.querySelector("[data-reco-img]").src = data[slugs[0]].img;
    f.querySelector("[data-reco-why]").textContent = wanted ? "" : r.why;
    f.querySelector("[data-reco-price]").textContent = (!wanted && r.budget) || data[slugs[0]].price || T.onRequest;
    ["metier", "usage", "lieu", "suite"].forEach(function (n) { f.querySelector('[data-r=' + n + ']').textContent = labels(n); });
    f.querySelector("[data-r=to]").textContent = (s.metier === "kine" && s.usages.indexOf("posture") !== -1) ? T.toPosturo : T.toDefault;
  }
  f.addEventListener("change", function (e) { if (e.target.name !== "msg") { if (e.target.name === "usage" || e.target.name === "lieu" || e.target.name === "metier") wanted = null; update(); } });
  update();

  function check(input, ok) {
    var err = document.getElementById(input.id + "-err");
    input.setAttribute("aria-invalid", ok ? "false" : "true");
    if (err) err.hidden = ok;
    return ok;
  }
  var nameI = f.elements.name, mailI = f.elements.email;
  var validName = function () { return check(nameI, nameI.value.trim().length > 1); };
  var validMail = function () { return check(mailI, /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mailI.value.trim())); };
  nameI.addEventListener("blur", function () { if (nameI.value) validName(); });
  mailI.addEventListener("blur", function () { if (mailI.value) validMail(); });
  nameI.addEventListener("input", function () { if (nameI.getAttribute("aria-invalid") === "true") validName(); });
  mailI.addEventListener("input", function () { if (mailI.getAttribute("aria-invalid") === "true") validMail(); });

  f.addEventListener("submit", function (e) {
    e.preventDefault();
    var okName = validName(), okMail = validMail();
    if (!okName) { nameI.focus(); return; }
    if (!okMail) { mailI.focus(); return; }
    var L = T.labels, el = f.elements;
    var body = [
      L.name + " : " + el.name.value.trim(),
      L.city + " : " + (el.city.value.trim() || T.toDefine),
      L.email + " : " + el.email.value.trim(),
      L.tel + " : " + (el.tel.value.trim() || T.toDefine),
      "",
      L.metier + " : " + labels("metier"),
      L.usage + " : " + labels("usage"),
      L.lieu + " : " + labels("lieu"),
      L.suite + " : " + labels("suite"),
      T.reco + " : " + current.map(function (k) { return data[k].name; }).join(", "),
      "",
      el.msg.value.trim()
    ].join("\n");
    var subject = T.subject + " · " + labels("suite") + " · " + current.map(function (k) { return data[k].name; }).join(", ");
    location.href = "mailto:" + f.getAttribute("data-to") + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
    f.querySelector("[data-done]").hidden = false;
  });
})();
</script>

</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
