<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>The range: pressure plates, walkways and posturology · Medicapteurs</title>
<meta name="description" content="The 13 Medicapteurs products compared: Minipod, T-Plate, Win-Pod Wifi, Fusyo, Win-Posturo, Win-Track, PowerTrack, W-Inshoe. Find the platform that suits your practice.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/">
<meta property="og:title" content="The range: pressure plates, walkways and posturology">
<meta property="og:description" content="The 13 Medicapteurs products compared: Minipod, T-Plate, Win-Pod Wifi, Fusyo, Win-Posturo, Win-Track, PowerTrack, W-Inshoe. Find the platform that suits your practice.">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-range">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn data-current>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/gamme/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap page-head">
  <span class="mc-eyebrow">Products</span>
  <h1 class="h1">Find the platform made for your practice.</h1>
  <p class="lead">Answer three questions, or browse the range by family. Every platform comes with its software.</p>
  <form class="finder" data-finder onsubmit="return false">
    <div class="finder__q"><label for="f-metier">1. Your profession</label>
      <select class="select" id="f-metier" name="metier">
        <option value="podo">Podiatrist</option><option value="medecin">Doctor, diabetologist</option><option value="kine">Physiotherapist, rehabilitation</option><option value="chercheur">Researcher</option><option value="sport">Sport</option><option value="pharma">Pharmacy, orthotics</option><option value="autre">Other</option>
      </select></div>
    <div class="finder__q"><label for="f-usage">2. What you measure</label>
      <select class="select" id="f-usage" name="usage">
        <option value="statique">Static</option><option value="pas" selected>One step</option><option value="marche">Several steps</option><option value="course">Running</option><option value="posture">Posture and balance</option><option value="chaussure">Inside the shoe</option>
      </select></div>
    <div class="finder__q"><label for="f-lieu">3. Where you use it</label>
      <select class="select" id="f-lieu" name="lieu">
        <option value="cabinet">In my practice</option><option value="mobile">On the move</option><option value="labo">In a laboratory</option>
      </select></div>
    <div class="finder__out" aria-live="polite">
      <div class="finder__reco"><strong>Our advice:</strong> <span data-finder-names><span class="mc-product"><span class="mc-sensor"></span>T-Plate</span> · <span class="mc-product"><span class="mc-sensor"></span>Win-Pod Wifi</span></span></div>
      <div class="finder__btns">
        <a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/" data-finder-see><span class="mc-sensor"></span><span>See the product</span></a>
        <a class="mc-btn mc-btn--primary" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/" data-finder-req><span class="mc-sensor"></span>Prepare my request</a>
      </div>
      <p class="muted" style="flex-basis:100%;font-size:15px;line-height:22px" data-finder-why></p>
    </div>
  </form>
</section>

<section class="wrap" style="padding-bottom:40px">
  <div class="family" id="mobile">
    <div class="family__head"><span class="mc-eyebrow">Mobile</span><h2 class="h2">Measure anywhere</h2><p>A lightweight platform driven by a smartphone or tablet.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="Minipod" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Minipod</span></span>
        <p>The platform that fits in a bag, driven by a smartphone.</p>
        <span class="mc-data">800 · 1 kg · 100 frames/s</span>
      </a>
    </div>
  </div>
  <div class="family" id="cabinet">
    <div class="family__head"><span class="mc-eyebrow">Clinic</span><h2 class="h2">Pressure plates</h2><p>Static, dynamic and postural analysis, with the full software on PC.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="T-Plate" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>T-Plate</span></span>
        <p>The everyday podiatry examination.</p>
        <span class="mc-data">1,600 · 400 × 400 mm · 3 kg</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="T-Plate 40" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>T-Plate 40</span><span class="tag-new">New</span></span>
        <p>The Medicapteurs 40th anniversary edition.</p>
        <span class="mc-data">Data sheet coming soon</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="T-Plate 30th" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>T-Plate 30th</span></span>
        <p>50% more active area and the full-option software.</p>
        <span class="mc-data">4,096 · 500 × 500 mm · 3.6 kg</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="XT-Plate" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>XT-Plate</span><span class="tag-new">New</span></span>
        <p>Light and cost-effective, in USB, Wi-Fi or Bluetooth.</p>
        <span class="mc-data">Data sheet coming soon</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="Win-Pod Wifi" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Pod Wifi</span></span>
        <p>The reference platform, from the lowest pressures to the highest.</p>
        <span class="mc-data">2,304 · 0.4 – 100 N · 300 frames/s</span>
      </a>
    </div>
  </div>
  <div class="family" id="posture">
    <div class="family__head"><span class="mc-eyebrow">Posturology</span><h2 class="h2">Posture and balance</h2><p>APE-standardised stabilometry and biofeedback rehabilitation.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="Fusyo" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Fusyo</span></span>
        <p>Podometry and stabilometry on a single platform.</p>
        <span class="mc-data">2,304 · 5 – 40 Hz · 250 kg</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="Win-Posturo" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Posturo</span></span>
        <p>The stabilometry and postural rehabilitation platform.</p>
        <span class="mc-data">16 bits · 5 – 40 Hz · 900 points/kg</span>
      </a>
    </div>
  </div>
  <div class="family" id="labo">
    <div class="family__head"><span class="mc-eyebrow">Laboratory and sport</span><h2 class="h2">Walking, running, the shoe</h2><p>Several steps in a row, treadmill running, pressure in real conditions.</p></div>
    <div class="cards">
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="Win-Track" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Track</span></span>
        <p>The one-piece walkway: 2 to 4 steps.</p>
        <span class="mc-data">12,288 · 200 frames/s · 2 – 4</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="Win-Track Mini" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>Win-Track Mini</span></span>
        <p>The one-metre walkway that fits in a practice.</p>
        <span class="mc-data">8,192 · 1,000 × 500 mm · 200 frames/s</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="PowerTrack" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>PowerTrack</span></span>
        <p>The first 2-in-1 treadmill.</p>
        <span class="mc-data">0.8 – 20 km/h · 200 frames/s · 4</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="W-Inshoe" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>W-Inshoe</span></span>
        <p>Pressure measured inside the shoe, in real conditions.</p>
        <span class="mc-data">2 × 9 · 100 Hz · 50 g</span>
      </a>
      <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/">
        <img class="card-img" src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="W-Inshoe Easy" width="400" height="300" loading="lazy">
        <span class="card-name"><span class="mc-product"><span class="mc-sensor"></span>W-Inshoe Easy</span></span>
        <p>Instrumented insoles, ready to slip into the shoe.</p>
        <span class="mc-data">4 · 8 · 35 – 46</span>
      </a>
    </div>
  </div>
</section>

<section id="comparateur" class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">Comparison</span><h2 class="h2">The platforms side by side</h2></div></div>
    <div class="cmp-wrap">
      <table class="cmp">
        <thead><tr><td></td><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a></th><th scope="col"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a></th></tr></thead>
        <tbody>
          <tr><th scope="row">Active area</th><td>200 × 400 mm</td><td>400 × 400 mm</td><td>500 × 500 mm</td><td>400 × 400 mm</td><td>400 × 400 mm</td><td>1,500 × 500 mm</td></tr>
          <tr><th scope="row">Sensors</th><td>800</td><td>1,600</td><td>4,096</td><td>2,304</td><td>2,304 + 3 gauges</td><td>12,288</td></tr>
          <tr><th scope="row">Sensor size</th><td>10 × 10 mm</td><td>10 × 10 mm</td><td>7.8 × 7.8 mm</td><td>8 × 8 mm</td><td>8 × 8 mm</td><td>7.8 × 7.8 mm</td></tr>
          <tr><th scope="row">Max. sampling rate</th><td>100 Hz</td><td>150 Hz</td><td>200 Hz <span class="check">to be confirmed</span></td><td>300 Hz <span class="check">to be confirmed</span></td><td>200 Hz <span class="check">to be confirmed</span></td><td>200 Hz</td></tr>
          <tr><th scope="row">Connection</th><td>Bluetooth · USB-C</td><td>USB · Wi-Fi · Bluetooth</td><td>USB · Wi-Fi</td><td>USB · Wi-Fi</td><td>USB · Wi-Fi</td><td>USB</td></tr>
          <tr><th scope="row">Control</th><td class="txt">Smartphone, tablet</td><td class="txt">PC, tablet</td><td class="txt">PC, tablet</td><td class="txt">PC, tablet</td><td class="txt">PC</td><td class="txt">PC</td></tr>
          <tr><th scope="row">APE stabilometry</th><td class="txt">—</td><td class="txt">—</td><td class="txt">—</td><td class="txt">—</td><td class="txt">Yes</td><td class="txt">—</td></tr>
          <tr><th scope="row">Diabetic foot report</th><td class="txt">Yes</td><td class="txt">Yes</td><td class="txt">Yes</td><td class="txt">Yes</td><td class="txt">Yes</td><td class="txt">Yes</td></tr>
          <tr><th scope="row">List price</th><td>€1,790</td><td>on request</td><td>on request</td><td>€8,319 <span class="check">to be confirmed</span></td><td>on request</td><td>€12,388 <span class="check">to be confirmed</span></td></tr>
        </tbody>
      </table>
    </div>
    <p class="note" style="margin-top:14px">Values taken from Medicapteurs data sheets and brochures. Values marked “to be confirmed” are being validated.</p>
  </div>
</section>


<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Torn between two models?</h2>
      <p>Four questions about your practice: we point you to the right platform and its indicative budget.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>of demo, by video or at your practice</span></li><li><b>Turnkey</b><span>delivery, installation and online training</span></li><li><b>Trade-in</b><span>of your old Medicapteurs platform</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">or call us</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


<script type="application/json" id="mc-products">{"minipod": {"name": "Minipod", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg", "price": "€1,790 incl. VAT"}, "t-plate": {"name": "T-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg", "price": null}, "t-plate-40": {"name": "T-Plate 40", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg", "price": null}, "t-plate-30th": {"name": "T-Plate 30th", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg", "price": null}, "xt-plate": {"name": "XT-Plate", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg", "price": null}, "win-pod-wifi": {"name": "Win-Pod Wifi", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg", "price": "€8,319 incl. VAT"}, "fusyo": {"name": "Fusyo", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg", "price": null}, "win-posturo": {"name": "Win-Posturo", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg", "price": null}, "win-track": {"name": "Win-Track", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg", "price": "€12,388 incl. VAT"}, "win-track-mini": {"name": "Win-Track Mini", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg", "price": "€9,925 incl. VAT"}, "powertrack": {"name": "PowerTrack", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg", "price": null}, "w-inshoe": {"name": "W-Inshoe", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg", "price": "€3,495 incl. VAT"}, "w-inshoe-easy": {"name": "W-Inshoe Easy", "url": "<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/", "img": "<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg", "price": "€5,600 incl. VAT"}}</script>

<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/reco.js"></script>
<script>
(function () {
  var form = document.querySelector("[data-finder]");
  var data = JSON.parse(document.getElementById("mc-products").textContent);
  var lang = document.documentElement.lang;
  var names = form.querySelector("[data-finder-names]"), see = form.querySelector("[data-finder-see]"), why = form.querySelector("[data-finder-why]"), req = form.querySelector("[data-finder-req]");
  var base = req.getAttribute("href");
  function update() {
    var s = { metier: form.metier.value, usages: [form.usage.value], lieu: form.lieu.value };
    var r = window.mcReco(s, lang);
    names.innerHTML = r.slugs.map(function (k) { return '<a class="mc-product" href="' + data[k].url + '"><span class="mc-sensor"></span>' + data[k].name + "</a>"; }).join(" · ");
    see.href = data[r.slugs[0]].url;
    see.lastElementChild.textContent = see.lastElementChild.textContent.replace(/ ·.*$/, "") + " · " + data[r.slugs[0]].name;
    why.textContent = r.why;
    req.href = base + "?metier=" + s.metier + "&usage=" + s.usages[0] + "&lieu=" + s.lieu;
  }
  form.addEventListener("change", update);
  update();
})();
</script>

</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
