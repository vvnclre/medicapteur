<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Postural rehabilitation with Physioplay · Medicapteurs</title>
<meta name="description" content="Physioplay: 6 visual-postural biofeedback games for balance rehabilitation, on a Medicapteurs platform.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/">
<meta property="og:title" content="Postural rehabilitation with Physioplay">
<meta property="og:description" content="Physioplay: 6 visual-postural biofeedback games for balance rehabilitation, on a Medicapteurs platform.">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-solution">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn data-current>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/solutions/reeducation/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">
<section class="wrap page-head sol-head">
  <div class="stack" style="gap:20px">
    <span class="mc-eyebrow">Solutions</span>
    <h1 class="h1">Rehabilitation</h1>
    <p class="lead">Rehabilitation brings together techniques that help reduce a patient&#39;s impairments and disabilities related to orthostatic balance.</p>
    <p class="body-text">Physioplay, Medicapteurs&#39; postural rehabilitation software, offers 6 visual-postural biofeedback games. The patient controls the game with their balance on the platform.</p><p class="body-text">The “Physioplay pack” includes a platform and the software. “Physioplay software” is for practitioners who already own a Medicapteurs platform: Win-Pod, Win-Track, Win-Track Mini, Fusyo, Win-Posturo, S-Plate or T-Plate.</p>
    <p class="body-text">More information on +33 5 62 57 74 60 or commercial@medicapteurs.fr.</p>
  </div>
  <figure class="sol-head__img"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/physioplay-rumble.jpg" alt="" width="1400" height="760"></figure>
</section>
<section class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">What it does for you</span><h2 class="h2">What measurement brings you</h2></div></div>
    <div class="benefits"><div class="benefit"><b>Rebuild</b><p>Optimal rebuilding of the patient&#39;s posturo-kinetic capacity through visual-postural biofeedback.</p></div><div class="benefit"><b>Adjust</b><p>Playful exercises that adjust to the progress of rehabilitation, with predefined levels or levels created in a few clicks.</p></div><div class="benefit"><b>Sequence</b><p>Automatically program a sequence of games.</p></div><div class="benefit"><b>Follow up</b><p>Record and track the patient&#39;s progress.</p></div></div>
    <p class="audience"><strong>Who it is for:</strong> Physiotherapists, orthotists, sports physicians, rehabilitation specialists, posturologists.</p>
  </div>
</section>

<section class="wrap" style="padding-top:40px"><div class="gal"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/physioplay-kass.jpg" alt="" loading="lazy"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/physioplay-bee.jpg" alt="" loading="lazy"></div></section>

<section class="wrap sec">
  <span class="mc-eyebrow" style="margin-bottom:16px">Suitable platforms</span>
  
<div class="related">
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
  
  <a class="mc-plate" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="72" height="54" loading="lazy"><span><span class="mc-product" style="font-size:13px">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
  
</div>

</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Try it with your own patients.</h2>
      <p>A 30-minute video demo, or at your practice depending on your region.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>of demo, by video or at your practice</span></li><li><b>Turnkey</b><span>delivery, installation and online training</span></li><li><b>Trade-in</b><span>of your old Medicapteurs platform</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">or call us</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
