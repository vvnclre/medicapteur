<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Scientific studies using Medicapteurs platforms · Medicapteurs</title>
<meta name="description" content="Nearly 400 published works and 130 theses using Medicapteurs platforms: podiatry, posturology, biomechanics, diabetology.">
<link rel="canonical" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">
<link rel="alternate" hreflang="en" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">
<link rel="alternate" hreflang="fr" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">
<link rel="alternate" hreflang="x-default" href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/">
<meta property="og:title" content="Scientific studies using Medicapteurs platforms">
<meta property="og:description" content="Nearly 400 published works and 130 theses using Medicapteurs platforms: podiatry, posturology, biomechanics, diabetology.">
<meta property="og:locale" content="en_GB">
<meta name="theme-color" content="#111214">
<link rel="icon" href="<?php echo esc_url( MC_URI ); ?>/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Mono:wght@400;500&family=Atkinson+Hyperlegible+Next:ital,wght@0,400;0,700;1,400&family=Michroma&family=Sora:wght@500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/tokens.css">
<link rel="stylesheet" href="<?php echo esc_url( MC_URI ); ?>/assets/css/main.css">
<script src="<?php echo esc_url( MC_URI ); ?>/assets/js/main.js" defer></script>
<?php wp_head(); ?>
</head>
<body class="page-studies">
<a class="skip" href="#contenu">Skip to content</a>
<header class="hdr" data-hdr>
  <div class="hdr__in">
    <a class="hdr__logo" href="<?php echo esc_url( MC_HOME ); ?>/en/" aria-label="Medicapteurs, home">
      <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-couleur.png" alt="Medicapteurs" width="142" height="42">
    </a>
    <nav class="hdr__nav" aria-label="Main navigation">
      <button class="hdr__link" type="button" aria-expanded="false" aria-controls="mega" data-menu-btn>Products<span class="hdr__chev" aria-hidden="true"></span></button>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-solutions" data-menu-btn>Solutions<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-solutions" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
        </div>
      </div>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a class="hdr__link" href="<?php echo esc_url( MC_HOME ); ?>/en/studies/" aria-current="page">Studies</a>
      <div class="hdr__item">
        <button class="hdr__link" type="button" aria-expanded="false" aria-controls="menu-company" data-menu-btn>About us<span class="hdr__chev" aria-hidden="true"></span></button>
        <div class="drop" id="menu-company" hidden data-menu>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
          <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        </div>
      </div>
    </nav>
    <div class="hdr__end">
      <nav class="lang" aria-label="Language">
        <a href="<?php echo esc_url( MC_HOME ); ?>/fr/etudes/" hreflang="fr" lang="fr" data-lang="fr" title="Français">FR</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/" hreflang="en" lang="en" data-lang="en" aria-current="true" class="on" title="English">EN</a>
      </nav>
      <a class="mc-btn mc-btn--primary hdr__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
      <button class="hdr__burger" type="button" aria-expanded="false" aria-controls="drawer" data-drawer-btn><span class="hdr__burger-i" aria-hidden="true"><i></i><i></i><i></i></span><span class="sr">Menu</span></button>
    </div>
  </div>

  <div class="mega" id="mega" hidden data-menu>
    <div class="mega__in">
      <div class="mega__needs">
        <span class="mc-eyebrow">By need</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Podiatry examination</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posture and balance</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Gait analysis</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Running and sport</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#mobile">Measuring on the move</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Compare models</a>
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Pressure plates</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/minipod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Minipod</span><small>800 sensors · smartphone</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate</span><small>1,600 sensors · USB, Wi-Fi</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-40.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 40</span><small>New · 40th anniversary</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/t-plate-30.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">T-Plate 30th</span><small>4,096 sensors · 50 × 50 cm</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/xt-plate.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">XT-Plate</span><small>New · 2026</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-pod.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Pod Wifi</span><small>2,304 sensors · the reference</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Gait and sport</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track</span><small>1.5 m walkway · 200 frames/s</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-track-mini-light.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Track Mini</span><small>1 m walkway · 2 steps</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/powertrack.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">PowerTrack</span><small>Treadmill 0.8 – 20 km/h</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/w-inshoe.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe</span><small>9 free sensors · 100 Hz</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/winshoe-easy.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">W-Inshoe Easy</span><small>Insoles EU 35 to 46</small></span></a>
        
        
      </div>
      
      <div class="mega__col">
        <span class="mc-eyebrow">Posturology</span>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/fusyo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Fusyo</span><small>Podometry + APE stabilometry</small></span></a>
        
        <a class="mega__it" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><img src="<?php echo esc_url( MC_URI ); ?>/assets/img/win-posturo.jpg" alt="" width="64" height="48" loading="lazy"><span><span class="mc-product">Win-Posturo</span><small>Stabilometry 5 – 40 Hz</small></span></a>
        
        
        <span class="mc-eyebrow mega__sub">Software</span>
        <a class="mega__it mega__it--text" href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span><span class="mc-product">Win-Pod V10 · Podocapture</span><small>Included with every platform</small></span></a>
        
      </div>
      
      <div class="mega__help">
        <strong>Torn between two models?</strong>
        <span>Four questions about your practice: we point you to the right platform and its indicative budget.</span>
        <a class="mc-btn mc-btn--primary mc-btn--sm" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Find my platform</a>
        <a class="mc-btn mc-btn--link" href="<?php echo esc_url( MC_HOME ); ?>/en/range/">See the whole range</a>
      </div>
    </div>
  </div>

  <div class="drawer" id="drawer" hidden data-drawer>
    <nav class="drawer__nav" aria-label="Main navigation">
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/">Products</a>
      <div class="drawer__prods">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/minipod/"><span class="mc-sensor"></span>Minipod</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-40/"><span class="mc-sensor"></span>T-Plate 40</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate-30th/"><span class="mc-sensor"></span>T-Plate 30th</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/xt-plate/"><span class="mc-sensor"></span>XT-Plate</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod Wifi</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track-mini/"><span class="mc-sensor"></span>Win-Track Mini</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/powertrack/"><span class="mc-sensor"></span>PowerTrack</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe-easy/"><span class="mc-sensor"></span>W-Inshoe Easy</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/"><span class="mc-sensor"></span>Software</a>
      </div>
      <span class="drawer__k">Solutions</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
      <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
      <span class="drawer__k">About us</span>
      <div class="drawer__sub">
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
      </div>
    </nav>
    <a class="mc-btn mc-btn--primary mc-btn--lg drawer__cta" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request</a>
    <a class="drawer__tel" href="tel:+33562571571">+33 5 62 571 571</a>
  </div>
</header>

<main id="contenu">

<section class="wrap page-head">
  <span class="mc-eyebrow">Research</span>
  <h1 class="h1 statement page-head__statement">Nearly 400 published works.</h1>
  <p class="lead">For 40 years, Medicapteurs has been a research partner worldwide, in podometry, posturology, biomechanics and diabetology. Here is the census drawn up by Medicapteurs in January 2023.</p>
</section>

<section class="wrap" style="padding-bottom:48px">
  <div class="cmp-wrap">
    <table class="cmp cmp--studies">
      <thead><tr><th scope="col">Platform</th><th scope="col">Published works</th><th scope="col">Period</th><th scope="col">Theses and unpublished works</th><th scope="col">Full lists</th></tr></thead>
      <tbody>
        <tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-posturo/"><span class="mc-sensor"></span>Win-Posturo</a></th>
          <td><span class="bar" style="--w:100%"></span>96</td><td>2000 – 2022</td><td>19</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/winposturo-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-winposturo_01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-pod-wifi/"><span class="mc-sensor"></span>Win-Pod</a></th>
          <td><span class="bar" style="--w:98%"></span>94</td><td>2003 – 2022</td><td>59</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/winpod-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-winpod_01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/fusyo/"><span class="mc-sensor"></span>Fusyo</a></th>
          <td><span class="bar" style="--w:88%"></span>84</td><td>2005 – 2022</td><td>11</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/fusyo-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-fusyo_01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr><tr>
          <th scope="row"><span class="mc-product"><span class="mc-sensor"></span>PEL38 (former platform)</span></th>
          <td><span class="bar" style="--w:45%"></span>43</td><td>1983 – 2021</td><td>10</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/pel38-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/pel38-non-published-work-01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/t-plate/"><span class="mc-sensor"></span>T-Plate · S-Plate</a></th>
          <td><span class="bar" style="--w:40%"></span>38</td><td>2007 – 2022</td><td>12</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/tplate-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoire-t-plate.s-plate.distributeurs.01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/win-track/"><span class="mc-sensor"></span>Win-Track</a></th>
          <td><span class="bar" style="--w:30%"></span>29</td><td>2009 – 2022</td><td>9</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/wintrack-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-wintrack_01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr><tr>
          <th scope="row"><a class="mc-product" href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/"><span class="mc-sensor"></span>W-Inshoe</a></th>
          <td><span class="bar" style="--w:9%"></span>9</td><td>2014 – 2022</td><td>9</td>
          <td class="txt"><a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/winshoe-published-work-01-2023.pdf" target="_blank" rel="noopener">Published</a> · <a href="https://www.medicapteurs.com/wp-content/uploads/sites/1772/2023/01/memoires-theses-winshoe_01-2023.pdf" target="_blank" rel="noopener">Theses</a></td>
        </tr>
        <tr class="total"><th scope="row">Total</th><td>≈ 393</td><td>1983 – 2022</td><td>≈ 129</td><td></td></tr>
      </tbody>
    </table>
  </div>
  <div class="genres"><div class="mc-measure"><b>127</b><em>Publications</em></div><div class="mc-measure"><b>93</b><em>Articles</em></div><div class="mc-measure"><b>79</b><em>Conference abstracts</em></div><div class="mc-measure"><b>33</b><em>Posters</em></div><div class="mc-measure"><b>14</b><em>Presentations</em></div></div>
  <p class="note">“Published” works include articles, conference abstracts, posters and presentations. The full lists, by platform, can be downloaded below. About 183 works in English and 154 in French.</p>
</section>
<section class="sec sec--alt">
  <div class="wrap">
    <div class="sec-h"><div><span class="mc-eyebrow">Selection</span><h2 class="h2">Selected works</h2></div><a class="mc-btn mc-btn--secondary" href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/"><span class="mc-sensor"></span>Diabetic foot studies</a></div>
    <div class="refs"><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Effect of the distance run and the rest periods on the static plantar pressure during a 24-hour running race</b><span>Farfaro M., Dumon L., Masmontet C. · European Journal of Human Movement, 2019</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Effectiveness of custom foot insoles to decrease plantar pressure: a cross-over randomized trial study</b><span>Casado-Hernández I., Becerro-de-Bengoa-Vallejo R., Losa-Iglesias M. · Healthcare, 2022</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>A cross-sectional study on the correlations between floating toe, plantar arch posture, and body sway</b><span>Wakoa M., Fujimaki T., Koyama K., Furuya N. · Foot and Ankle Surgery, 2022</span></div><div class="ref"><span class="mc-eyebrow">Fusyo</span><b>The effects of unilateral medial arch support stimulation on plantar pressure and center of pressure adjustment in young gymnasts</b><span>Janin M., Dupui P. · Neuroscience Letters, 2009</span></div><div class="ref"><span class="mc-eyebrow">Fusyo</span><b>Effect of eccentric isokinetic strengthening in the rehabilitation of patients with knee osteoarthritis: Isogo, a randomized trial</b><span>Jégu A.-G., Pereira B., Andant N., Coudeyre E. · Trials, 2014</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Biomechanical evaluation of diabetic foot through hierarchical cluster analysis</b><span>Sawacha Z., Spolaor F., Guarneri G. et al. · Université de Padoue</span></div><div class="ref"><span class="mc-eyebrow">Win-Track</span><b>Analysis of gait characteristics using a dynamic foot scanner in type 2 diabetes mellitus without peripheral neuropathy</b><span>Chenamgere G. S. K., Maiya A. G. et al. · Journal of Exercise Science and Physiotherapy, 2015</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>Standing hindfoot alignment and body sway in healthy adolescents</b><span>Turci M., Ranghino C., Colaccino V., Grassi G. P. · poster, 2007</span></div><div class="ref"><span class="mc-eyebrow">Win-Pod</span><b>La baropodométrie</b><span>Cornu J.-Y., Dussaucy A., Jeunet L. · Progrès en médecine et chirurgie du pied, 2004</span></div><div class="ref"><span class="mc-eyebrow">Fusyo · Win-Pod</span><b>Sensibilité et motricité podales : leur influence sur le contrôle des activités posturo-cinétiques de sujets sains et pathologiques</b><span>Janin M. · thèse, Université Paul Sabatier Toulouse III, 2009</span></div></div>
  </div>
</section>
<section class="wrap sec">
  <span class="mc-eyebrow" style="margin-bottom:16px">They work with Medicapteurs</span>
  <div class="tiles"><div class="tile"><b>Marc Janin</b><span>Podiatrist, PhD. Baropodometry master class at Medicapteurs in February 2017, webinars 2020-2021.</span></div><div class="tile"><b>Jean-Yves Cornu</b><span>Podiatrist, many publications with Win-Pod.</span></div><div class="tile"><b>Marc Bourgeois</b><span>Biomechanist.</span></div></div>
</section>

<section class="wrap" style="padding-top:48px;padding-bottom:64px">
  <div class="cta-band">
    <div class="cta-band__main">
      <h2 class="cta-band__t">Try it with your own patients.</h2>
      <p>A 30-minute video demo, or at your practice depending on your region.</p>
      <ul class="cta-band__list"><li><b>30 min</b><span>of demo, by video or at your practice</span></li><li><b>Turnkey</b><span>delivery, installation and online training</span></li><li><b>Trade-in</b><span>of your old Medicapteurs platform</span></li></ul>
    </div>
    <div class="cta-band__side">
      <a class="mc-btn mc-btn--ink mc-btn--lg" href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/"><span class="mc-sensor"></span>Prepare my request<span class="mc-cells" aria-hidden="true"><i></i><i></i><i></i></span></a>
      <span class="cta-band__or">or call us</span>
      <a class="cta-band__tel" href="tel:+33562571571">+33 5 62 571 571</a>
    </div>
    <div class="cta-band__print" aria-hidden="true"><div class="step" data-step="0"></div><div class="step step--r" data-step="0"></div></div>
  </div>
</section>


</main>
<footer class="ftr mc-on-inverse">
  <div class="wrap ftr__in">
    <div class="ftr__grid">
      <div class="ftr__brand">
        <img src="<?php echo esc_url( MC_URI ); ?>/assets/img/medicapteurs-logo-fond-sombre.png" alt="Medicapteurs" width="121" height="34">
        <p>Plantar pressure measurement platforms, designed and made in Balma, France, since 1985.</p>
        <a class="ftr__tel" href="tel:+33562571571">+33 5 62 571 571</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Products</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#cabinet">Pressure plates</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#labo">Walkways</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#posture">Posturology</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/products/w-inshoe/">In-shoe sensors</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/software/">Software</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/range/#comparateur">Comparison table</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Solutions</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/baropodometry/">Baropodometry</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/posturography/">Posturography</a><a href="<?php echo esc_url( MC_HOME ); ?>/en/solutions/rehabilitation/">Rehabilitation</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/diabetic-foot/">Diabetic foot</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/engineering/">Custom engineering</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Resources</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/understanding-measurement/">Understanding measurement</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/studies/">Studies</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/downloads/">Downloads</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/support/">Support and hotline</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/news/">News</a>
      </div>
      <div class="ftr__col">
        <span class="ftr__k">Company</span>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/about-us/">Our story</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/distribution/">Distribution</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/contact/">Contact</a>
        <a href="<?php echo esc_url( MC_HOME ); ?>/en/prepare-my-request/">Prepare my request</a>
        <span class="ftr__muted">Balma · Sophia Antipolis</span>
      </div>
    </div>
    <div class="ftr__base">
      <span>Medical devices. Class, regulation and notified body: to be specified by Medicapteurs.</span>
      <span><a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/">Legal notice</a> · <a href="<?php echo esc_url( MC_HOME ); ?>/en/legal-notice/#donnees">Privacy</a> · © 2026 Medicapteurs</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
